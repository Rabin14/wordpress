<div class="container-medium">
    <div class="footer-sidebar">
        <?php if ( is_active_sidebar( 'footer-sidebar' ) ) { ?>
            <?php dynamic_sidebar( 'footer-sidebar' ); ?>
        <?php } ?>
    </div>
</div>