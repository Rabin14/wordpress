<div class="container-fluid">
    <div class="row">
        <div class="col project-content">
            <?php the_content(); ?>
        </div>
    </div>
</div>
