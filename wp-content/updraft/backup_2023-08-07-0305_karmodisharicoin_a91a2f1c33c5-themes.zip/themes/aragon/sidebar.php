<aside class="blog-sidebar">
    <?php if ( is_active_sidebar( 'blog-sidebar' ) ) { ?>
        <?php dynamic_sidebar( 'blog-sidebar' ); ?>
    <?php } ?>
</aside>