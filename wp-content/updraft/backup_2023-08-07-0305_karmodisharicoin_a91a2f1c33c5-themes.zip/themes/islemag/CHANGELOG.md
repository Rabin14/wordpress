
 ### v1.1.14 - 2018-11-28 
 **Changes:** 
 * new screenshot
* default background image changed
* readme updated
 
 ### v1.1.13 - 2018-11-27 
 **Changes:** 
 * - Fixed hiding related posts not SEO friendly
* - Fixed long content breaking layout in blog posts
* - Notice about Neve added in Dashboard
* - Updated readme.txt file
 
### 1.1.10 - 06/02/2018
**Changes:** 
- Made the number of comments visible only for posts that allow comments


### 1.1.9 - 08/12/2017

**Changes:** 

- New option to change the copyright text

- Added some missing translations functions

- Fixed compatibility issue with WP Product Review Lite


### 1.1.7 - 15/09/2017

**Changes:** 

- Fixed SEO issues: H1 tag for single pages titles and Site title and tagline corresponding tags

- New option for randomizing the posts from the Slider


### 1.1.6 - 10/07/2017

**Changes:** 

- Fixed issue with Advertisement areas


### 1.1.5 - 25/05/2017

**Changes:** 

- Make functions in extras.php changeable from a child theme

- Fixed issues with AdSense code not working in widgets


### 1.1.4 - 06/04/2017

**Changes:** 

- Added images for demo preview

- New filters for child themes usage

- Fixed issue with widgets line when links are used


### 1.1.3 - 16/03/2017

**Changes:** 

- Fixed error with mobile menu not working when the Sticky menu option is disabled


### 1.1.2 - 13/01/2017

**Changes:** 

- Removed frontpage template and use the front-page.php file for the frontpage

- Fixed small issue with child themes date in archive page


### 1.1.1 - 30/12/2016

**Changes:** 

- Added grunt and fixed all generated errors

- Update carousel library to fix issue with menu on mobile


### 1.1.0 - 29/11/2016

**Changes:** 

- Reorganize customize upsells

- Added hooks and filters for better use with child themes

- Added grunt


### 1.0.15 - 09/11/2016

**Changes:** 

- Fixed social icons not working on mobile devices

- Fixed header banner spacing issue


### 1.0.14 - 01/11/2016

**Changes:** 

- New option to disable each frontpage section

- Redo the socials repeater box to better UI experience


### 1.0.12 - 22/08/2016

**Changes:** 

- Fixed spacing issues in posts and pages

- Allow adsense code in widgets

- Add link to documentation


### 1.0.11 - 02/06/2016

**Changes:** 

- Update version


### 1.0.10 - 02/06/2016

**Changes:** 

- Added About IsleMag page in dashboard

- Improved image sizes management


### 1.0.10 - 23/05/2016

**Changes:** 

- Development

 
### 1.0.9 - 20/05/2016 
**Changes:** 
- Development 
 
### 1.0.8 - 19/05/2016 
**Changes:** 
- Development 
 
### 1.0.7 - 17/05/2016 
**Changes:** 
- Development 
 ### 1.0.6 - 10/05/2016 Changes: islemag #143 - fixed sidebar issue islemag Revert "#143 - fixed sidebar issue" This reverts commit 59f9673f2363ab1fb95b92d14c3abb57a0fc214c. islemag #145 - added option to hide the thumbnail on single page islemag Merge pull request #147 from cristian-ungureanu/development Development ### 1.0.5 - 04/05/2016 Changes: islemag Merge pull request #131 from cristian-ungureanu/development Development ### 1.0.4 - 04/04/2016 Changes: islemag Merge pull request #111 from cristian-ungureanu/development !!! fix theme-check errors islemag Merge pull request #112 from cristian-ungureanu/development Development ### 1.0.4 - 04/04/2016 Changes: islemag Merge pull request #109 from cristian-ungureanu/development Development ### 1.0.3 - 28/03/2016 Changes: islemag Merge pull request #105 from cristian-ungureanu/development Development ### 1.0.2 - 25/02/2016 Changes: islemag #93 - add star rating to posts that have wppr islemag #92 - added widget area before each section islemag #91 - add widget area in header islemag Merge pull request #95 from cristian-ungureanu/development Development islemag Merge pull request #96 from cristian-ungureanu/development !!! change widget recomandation islemag Merge pull request #97 from cristian-ungureanu/development !!! top banner fix islemag Merge pull request #98 from cristian-ungureanu/development !!! fix css for comment form on responsive islemag Merge pull request #100 from cristian-ungureanu/development !!! change theme version ### 1.0.1 - 10/02/2016 Changes: islemag #21 - prefix all handle names islemag added control for header banner, now you can choose between image and code islemag Merge pull request #42 from cristian-ungureanu/development Development islemag Merge pull request #43 from cristian-ungureanu/development !!! small css fixes islemag Merge pull request #57 from cristian-ungureanu/development Development islemag Merge pull request #58 from cristian-ungureanu/development !!! small change islemag Merge pull request #59 from cristian-ungureanu/development !!! small fix islemag Merge pull request #60 from cristian-ungureanu/development Development islemag Merge pull request #61 from cristian-ungureanu/development !!! css fix islemag Merge pull request #62 from cristian-ungureanu/development !!! css fix islemag Merge pull request #63 from cristian-ungureanu/development !!! css fix islemag Merge pull request #64 from cristian-ungureanu/development !!! small fix islemag Merge pull request #74 from cristian-ungureanu/development Development islemag Merge pull request #75 from cristian-ungureanu/development Development islemag Merge pull request #76 from cristian-ungureanu/development !!! this fixes pirate form style islemag Merge pull request #77 from cristian-ungureanu/development !!! fix comment form islemag Merge pull request #78 from cristian-ungureanu/development !!! small css fix islemag Merge pull request #79 from cristian-ungureanu/development !!! css fixes islemag Merge pull request #80 from cristian-ungureanu/development !!!fix css islemag Merge pull request #81 from cristian-ungureanu/development !!! css fix islemag Merge pull request #82 from cristian-ungureanu/development !!!css fix islemag Merge pull request #83 from cristian-ungureanu/development !!! style for rss feed islemag Merge pull request #84 from cristian-ungureanu/development !!! fix islemag Merge pull request #85 from cristian-ungureanu/development !!!fix islemag Merge pull request #86 from cristian-ungureanu/development !!! fix islemag Merge pull request #87 from cristian-ungureanu/development !!! css fix islemag Merge pull request #88 from cristian-ungureanu/development !!! css fix ### 1.0.0 - 17/12/2015 Changes: islemag Merge pull request #13 from cristian-ungureanu/development !!! removed unused files, added readme ### 1.0.0 - 17/12/2015 Changes: islemag Merge pull request #11 from cristian-ungureanu/development Development ### 1.0.0 - 17/12/2015 Changes: islemag Merge pull request #6 from cristian-ungureanu/development !!! fixed colors and menus islemag Merge pull request #7 from cristian-ungureanu/development !!! fix background change islemag Merge pull request #8 from Codeinwp/production Small changes islemag Revert "Small changes" islemag Merge pull request #9 from Codeinwp/revert-8-production Revert "Small changes"
