<?php

class aragon_Flickr_Widget extends WP_Widget {
// Main constructor
	public function __construct() {
		$widget_id       = 'aragon_flickr_widget';
		$widget_title    = __( 'Flickr Feed', 'aragon_widgets' );
		$widget_settings = array(
			'customize_selective_refresh' => true,
			'classname'                   => 'aragon_flickr_widget',
			'description'                 => esc_html__( 'Flickr Feed', 'aragon_widgets' )
		);
		parent::__construct( $widget_id, $widget_title, $widget_settings );
	}

// The widget form (for the backend )
	public function form( $instance ) {
// Set widget defaults
		$defaults = array(
			'title'   => esc_html__( 'Flickr Feed', 'aragon_widgets' ),
			'user_id' => '158355145@N08',
			'count'   => '6',
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>
        <!-- Title -->
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php _e( 'Widget Title', 'aragon_widgets' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text"
                   value="<?php echo esc_attr( $instance['title'] ); ?>"/>
        </p>
        <!-- User ID -->
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'user_id' ) ); ?>"><?php _e( 'User ID:', 'aragon_widgets' ); ?></label>
            <input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'user_id' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'user_id' ) ); ?>" value="<?php echo esc_attr( $instance['user_id'] ); ?>"/>
        </p>
        <!-- Photos Count -->
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>"><?php _e( 'Photos Count:', 'aragon_widgets' ); ?></label>
            <input type="number" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'count' ) ); ?>" value="<?php echo esc_attr( $instance['count'] ); ?>"/>
        </p>
		<?php
	}

// Update widget settings
	public function update( $new_instance, $old_instance ) {
		$instance            = $old_instance;
		$instance['title']   = isset( $new_instance['title'] ) ? wp_strip_all_tags( $new_instance['title'] ) : '';
		$instance['user_id'] = isset( $new_instance['user_id'] ) ? wp_strip_all_tags( $new_instance['user_id'] ) : '';
		$instance['count']   = isset( $new_instance['count'] ) ? wp_strip_all_tags( $new_instance['count'] ) : '';

		return $instance;
	}

// Display the widget
	public function widget( $args, $instance ) {
		extract( $args );
		// Check the widget options
		$title   = isset( $instance['title'] ) ? apply_filters( 'widget_title', $instance['title'] ) : 'Flickr Feed';
		$user_id = isset( $instance['user_id'] ) ? $instance['user_id'] : '151370694@N06';
		$count   = isset( $instance['count'] ) ? $instance['count'] : '';
		echo $before_widget;
		if ( $title ) :
			echo aragon_wp_kses( $before_title ) . esc_attr( $title ) . aragon_wp_kses( $after_title );
		endif; ?>
        <div class="flickr-widget">
            <ul>
				<?php
				$url = 'http://api.flickr.com/services/feeds/photos_public.gne?id=' . $user_id . '&format=json';
				$ch  = curl_init( $url );
				curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
				$response = curl_exec( $ch );
				curl_close( $ch );
				$json   = preg_replace( '/\\\([^"])/', '$1', substr( $response, 15, - 1 ) );
				$flickr = json_decode( $json );
				if ( empty( $flickr ) || is_wp_error( $flickr->items ) ):
					esc_attr_e( 'You provide invalid user ID', 'aragon_widgets' );
				else:
					for ( $i = 1; $i <= $count; $i ++ ): $img = $flickr->items[ $i ]; ?>
                        <li>
                            <a target="_blank" href="<?php echo $img->link; ?>">
                                <img src="<?php echo $img->media->m; ?>" alt="<?php echo $img->title ?>">
                                <div class="hover">
                                    <i class="fab fa-flickr"></i>
                                </div>
                            </a>
                        </li>
					<?php endfor; endif; ?>
            </ul>
        </div>
		<?php echo $after_widget;
	}
}

// Register Widget
function aragon_register_flickr_widget() {
	register_widget( 'aragon_Flickr_Widget' );
}

add_action( 'widgets_init', 'aragon_register_flickr_widget' );