<?php
class aragon_Instagram_Widget extends WP_Widget {
// Main constructor
	public function __construct() {
		$widget_id       = 'aragon_instagram_widget';
		$widget_title    = __( 'Instagram Feed', 'aragon_widgets' );
		$widget_settings = array(
			'customize_selective_refresh' => true,
			'classname'                   => 'aragon_instagram_widget',
			'description'                 => esc_html__( 'Instagram Feed', 'aragon_widgets' )
		);
		parent::__construct( $widget_id, $widget_title, $widget_settings );
	}
// The widget form (for the backend )
	public function form( $instance ) {
// Set widget defaults
		$defaults = array(
			'title' => esc_html__( 'Instagram Feed', 'aragon_widgets' ),
			'user'  => aragon_get_option( 'instagram_username' ),
			'count' => '6',
			'token' => aragon_get_option( 'instagram_access_token' )
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>
		<!-- Title -->
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php _e( 'Widget Title', 'aragon_widgets' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>"/>
		</p>
		<!-- Username -->
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'user' ) ); ?>"><?php _e( 'Username:', 'aragon_widgets' ); ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'user' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'user' ) ); ?>" value="<?php echo esc_attr( $instance['user'] ); ?>"/>
		</p>
		<!-- Photos Count -->
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>"><?php _e( 'Photos Count:', 'aragon_widgets' ); ?></label>
			<input type="number" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'count' ) ); ?>" value="<?php echo esc_attr( $instance['count'] ); ?>"/>
		</p>
		<!-- Access Token -->
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'token' ) ); ?>"><?php _e( 'Access Token:', 'aragon_widgets' ); ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'token' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'token' ) ); ?>" value="<?php echo esc_attr( $instance['token'] ); ?>"/>
		</p>
		<?php
	}
// Update widget settings
	public function update( $new_instance, $old_instance ) {
		$instance          = $old_instance;
		$instance['title'] = isset( $new_instance['title'] ) ? wp_strip_all_tags( $new_instance['title'] ) : '';
		$instance['user']  = isset( $new_instance['user'] ) ? wp_strip_all_tags( $new_instance['user'] ) : '';
		$instance['count'] = isset( $new_instance['count'] ) ? wp_strip_all_tags( $new_instance['count'] ) : '';
		$instance['token'] = isset( $new_instance['token'] ) ? wp_strip_all_tags( $new_instance['token'] ) : '';
		return $instance;
	}
// Display the widget
	public function widget( $args, $instance ) {
		extract( $args );
		// Check the widget options
		$title = isset( $instance['title'] ) ? apply_filters( 'widget_title', $instance['title'] ) : 'Instagram Feed';
		$user  = isset( $instance['user'] ) ? $instance['user'] : aragon_get_option( 'instagram_username' );
		$count = isset( $instance['count'] ) ? $instance['count'] : '6';
		$token = isset( $instance['token'] ) ? $instance['token'] : aragon_get_option( 'instagram_access_token' );
		$username     = $user ? $user : 'aragon_themes';
		$count_photos = $count ? $count : 6;
		$access_token = $token ? $token : '6900661842.1677ed0.303669110ce44ec08963e2df77ac2481';
		$response = wp_remote_get( sprintf( 'https://api.instagram.com/v1/users/self/media/recent/?access_token=%s&count=%s', $access_token, $count_photos ) );
		if ( is_wp_error( $response ) || 200 != wp_remote_retrieve_response_code( $response ) ) {
			return false;
		}
		$data        = json_decode( wp_remote_retrieve_body( $response ) );
		$user_object = $data->data[0]->user;
		$user        = array(
			'fullname'        => $user_object->full_name,
			'profile_picture' => $user_object->profile_picture,
			'username'        => empty( $username ) ? $user_object->username : $username,
			'id'              => $user_object->id
		);
		$media       = array();
		$i           = 0;
		foreach ( $data->data as $item ) {
			$media[ $i ] = array(
				'type'           => $item->type,
				'link'           => $item->link,
				'id'             => $item->id,
				'created_time'   => $item->created_time,
				'comments'       => $item->comments->count,
				'tags'           => $item->tags,
				'likes'          => $item->likes->count,
				'location'       => $item->location,
				'users_in_photo' => $item->users_in_photo,
				'attribution'    => $item->attribution,
				'filter'         => $item->filter,
				'user_has_liked' => $item->user_has_liked,
				'caption'        => $item->caption,
			);
			if ( $item->type == 'image' ) {
				$media[ $i ]['images'] = $item->images;
			} elseif ( $item->type == 'video' ) {
				$media[ $i ]['videos'] = $item->videos;
			} elseif ( $item->type == 'carousel' ) {
				$media[ $i ]['carousel_media'] = $item->carousel_media;
			}
			$i ++;
		}
		$result = array(
			'user'  => $user,
			'media' => $media
		);
		$instagram_images = $result;
		echo $before_widget;
		if ( $title ) :
			echo aragon_wp_kses( $before_title ) . esc_attr( $title ) . aragon_wp_kses( $after_title );
		endif; ?>
		<div class="instagram-widget">
			<?php
			if ( ! $instagram_images ) { ?>
				<div class="wp-error-wrap">
					<?php echo esc_attr( 'You Provide Invalid Access Token', 'aragon_widgets' ); ?>
				</div>
			<?php } else {
				$media = $instagram_images['media']; ?>
				<ul>
					<?php foreach ( $media as $item ):
						$type = $item['type'];
						$url = $item['link'];
						$date = gmdate( get_option( 'date_format' ), $item['created_time'] );
						$comments_count = $item['comments'];
						$likes_count = $item['likes'];
						$tags = implode( ', ', $item['tags'] );
						$id = $item['id'];
						$title = ! empty( $tags ) ? '#' . $tags : $date; ?>

						<li>
							<a target="_blank" href="<?php echo esc_url( $url ); ?>">

								<?php if ( $type == 'image' ): ?>

									<?php $media_url = $item['images']->standard_resolution->url; ?>
									<img class="instagram-image" src="<?php echo esc_url( $media_url ); ?>" alt="<?php echo esc_attr( $title ); ?>">

								<?php elseif ( $type == 'video' ): ?>

									<?php $media_url = $item['videos']->standard_resolution->url; ?>
									<video src="<?php echo esc_url( $media_url ); ?>"></video>

								<?php elseif ( $type == 'carousel' ): ?>

									<?php $carousel_item = $item['carousel_media'][0]; ?>
									<img class="instagram-image" src="<?php echo esc_url( $carousel_item->images->standard_resolution->url ); ?>" alt="<?php echo esc_attr( $title ); ?>">
								<?php endif; ?>

								<div class="hover">
									<i class="fab fa-instagram"></i>
								</div>
							</a>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php } ?>
		</div>
		<?php echo $after_widget;
	}
}

// Register Widget
function aragon_register_instagram_widget() {
	register_widget( 'aragon_Instagram_Widget' );
}

add_action( 'widgets_init', 'aragon_register_instagram_widget' );