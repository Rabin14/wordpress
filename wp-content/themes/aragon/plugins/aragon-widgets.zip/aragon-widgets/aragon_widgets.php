<?php
/*
Plugin Name: Aragon Widgets
Plugin URI: https://themeforest.net/user/jd-themes
Description: Widgets for Wordpress
Author: JD-Themes
Version: 1.0
License:      GPLv2 or later
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  aragon_widgets
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

load_plugin_textdomain( 'aragon_widgets', false, basename( dirname( __FILE__ ) ) . '/lang' );

define( 'WIDGETS_PATH', plugin_dir_path( __FILE__ ) . 'widgets' );

require_once( WIDGETS_PATH . '/recent_posts.php' );
require_once( WIDGETS_PATH . '/flickr_widget.php' );
require_once( WIDGETS_PATH . '/instagram_widget.php' );