jQuery(document).ready(($) => {
    "use strict";


    function views() {

        if (jdViews.id !== '') {

            $.ajax({
                type: 'POST',
                url: jdViews.ajax_url,
                data: {
                    action: 'lester_views',
                    nonce: jdViews.nonce,
                    id: jdViews.id,
                    useragent: jdViews.useragent
                },
                beforeSend: function () {
                },
                success: function (response) {

                }
            });

        }


    }

    setTimeout(views(), 1000);


}); // jQuery doc ready function







