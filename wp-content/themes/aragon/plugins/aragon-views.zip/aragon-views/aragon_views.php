<?php
/*
Plugin Name: JD Views
Plugin URI: https://themeforest.net/user/jd-themes
Description: Widgets for Wordpress
Author: JDThemes
Version: 1.0
License:      GPLv2 or later
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  lester_views
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Textdomain
load_plugin_textdomain( 'lester_views', false, basename( dirname( __FILE__ ) ) . '/lang' );

// Script
add_action( 'wp_enqueue_scripts', 'lester_views_add_scripts' );
function lester_views_add_scripts() {
    wp_enqueue_script( 'jd-views-js', plugin_dir_url( __FILE__ ) . '/views.js', array( 'jquery' ) );

    wp_localize_script( 'jd-views-js',
        'jdViews',
        array(
            'ajax_url'  => admin_url( 'admin-ajax.php' ),
            'nonce'     => wp_create_nonce( 'jd-views' ),
            'id'        => get_the_ID(),
            'useragent' => $_SERVER['HTTP_USER_AGENT']
        ) );
}

// PHP Handler
add_action( 'wp_ajax_nopriv_lester_views', 'lester_postviews' );
add_action( 'wp_ajax_lester_views', 'lester_postviews' );

function lester_postviews() {
    $id       = (int) $_POST['id'];
    $meta_key = 'lester_views';
    $cookie   = true;


    if ( function_exists( 'lester_get_option' ) ) :

        $cookie = lester_get_option( 'lester_enable_cookies_views' );

    endif;


    if ( get_post_meta( $id, $meta_key, true ) ) :

        $views = get_post_meta( $id, $meta_key, true );

    else :

        $views = 0;
        add_post_meta( $id, $meta_key, $views, true );

    endif;


    if ( function_exists( 'lester_get_option' ) && ! empty( lester_get_option( 'lester_visit_views' ) ) ) :

        $users = lester_get_option( 'lester_visit_views' );

    else :

        $users = 'guests';

    endif;

    if ( $users == 'all' ) :

        $can_update = true;

    elseif ( $users == 'guests' && ! is_user_logged_in() ) :

        $can_update = true;

    elseif ( $users == 'logged ' && is_user_logged_in() ) :

        $can_update = true;

    else :

        $can_update = false;

    endif;

    // Check google robots
    $useragent = $_POST['useragent'];
    $notbot    = "Mozilla|Opera";
    $bot       = "Bot/|robot|Slurp/|yahoo";

    if ( ! preg_match( "/$notbot/i", $useragent ) || preg_match( "!$bot!i", $useragent ) ) :

        $can_update = false;

    endif;

    if ( isset( $_COOKIE["lester_views_{$id}"] ) && $_COOKIE["lester_views_{$id}"] == 'visited' ) :

        $can_update = false;

    endif;

    if ( $can_update ) :

        update_post_meta( $id, $meta_key, ( $views + 1 ) );
        if ( $cookie ) :

            setcookie( "lester_views_{$id}", "visited", time() + 360000, '/', $_SERVER['HTTP_HOST'] );

        endif;

    endif;

    die();
}


function lester_get_postviews(){
    $id    = get_the_ID();
    $views = get_post_meta( $id, 'lester_views', true );
    $views = $views ? $views : '0';

    return $views;
}

function lester_the_postviews() {
    echo lester_get_postviews();
}



