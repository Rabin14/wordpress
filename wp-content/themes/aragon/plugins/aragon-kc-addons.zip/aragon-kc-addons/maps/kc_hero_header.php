<?php
if ( function_exists( 'kc_add_map' ) ) :
	kc_add_map(
		array(
			'kc_hero_header' => array(
				'name'       => __( 'Hero Header', 'aragon_kc_addons' ),
				'title'      => __( 'Hero Header', 'aragon_kc_addons' ),
				'admin_view' => __( 'Hero Header', 'aragon_kc_addons' ),
				'icon'       => 'aragon-hero-header',
				'category'   => 'Aragon-KC-Addons',
				'nested'     => true,
				'priority'   => 101,
				'css_box'    => true,
				'params'     => array(
					'general' => array(
						array(
							'name' => 'kc_hero_height',
							'label' => __('Hero Header height','aragon_kc_addons'),
							'type' => 'number_slider',
							'options' => array(
								'min' => 40,
								'max' => 100,
								'unit' => 'vh',
								'show_input' => true
							),
						),
                        array(
                            'name'    => 'kc_scroll_down',
                            'label'   => __( 'Scroll down icon', 'aragon_kc_addons' ),
                            'type'    => 'toggle',
                            'value'   => 'yes',
                            'options' => array( 'yes' => 'Enable' )
                        ),
						array(
							'name'    => 'kc_social_link_toggle',
							'label'   => __( 'Social links', 'aragon_kc_addons' ),
							'type'    => 'toggle',
							'value'   => 'yes',
							'options' => array( 'yes' => 'Enable' )
						),
						array(
							'type'     => 'group',
							'label'    => __( 'Social link', 'aragon_kc_addons' ),
							'name'     => 'kc_social_links_group',
							'options'  => array( 'add_link' => __( 'Add new link', 'aragon_kc_addons' ) ),
							'relation' => array(
								'parent'    => 'kc_social_link_toggle',
								'show_when' => 'yes'
							),
							'params'   => array(
								array(
									'name'        => 'kc_social_link',
									'label'       => __( 'social link', 'aragon_kc_addons' ),
									'type'        => 'link',
									'description' => __( 'Enter social link', 'aragon_kc_addons' ),
								),
								array(
									'name'  => 'kc_social_icon',
									'label' => __( 'Select icon', 'aragon_kc_addons' ),
									'type'  => 'icon_picker',
								),
							)
						),
					),
					'styles'  => array(
						array(
							'name'  => 'kc_hero_header_styles',
							'label' => __( 'Styles', 'aragon_kc_addons' ),
							'type'  => 'css',
						)
					)
				)
			),
		)
	);
endif;