<?php
if ( function_exists( 'kc_add_map' ) ) :
    kc_add_map(
        array(
            'kc_custom_accordions' => array(
                'name'         => __( 'Accordions', 'aragon_kc_addons' ),
                'title'        => __( 'Accordions', 'aragon_kc_addons' ),
                'admin_view'   => __( 'Accordions', 'aragon_kc_addons' ),
                'icon'         => 'aragon-accordions',
                'category'     => 'Aragon-KC-Addons',
                'is_container' => true,
                'priority'     => 101,
                'views'        => array(
                    'type'     => 'views_sections',
                    'sections' => 'kc_custom_accordions_accordion',
                    'display'  => 'vertical'
                ),
                'params'       => array(
                    'general' => array(
                        array(
                            'name' => 'kc_accordions_type',
                            'label' => __('Accordions type','aragon_kc_addons'),
                            'type' => 'radio',
                            'options' => array(
                                'accordions-type-1' => 'Accordions type 1',
                                'accordions-type-2' => 'Accordions type 2',
                                'accordions-type-3' => 'Accordions type 3',
                            ),
                            'value' => 'accordions-type-1',
                        ),
                    ),
                ),
            ),
        )
    );
endif;
