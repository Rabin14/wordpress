<?php
if ( function_exists( 'kc_add_map' ) ) :
	kc_add_map(
		array(
			'kc_video_box' => array(
				'name'       => __( 'Video box', 'aragon_kc_addons' ),
				'title'      => __( 'Video box', 'aragon_kc_addons' ),
				'admin_view' => __( 'Video box', 'aragon_kc_addons' ),
				'icon'       => 'aragon-video',
				'category'   => 'Aragon-KC-Addons',
				'priority'   => 103,
				'css_box'    => true,
				'params'     => array(
					'general' => array(
                        array(
                            'name'    => 'kc_video_box_type',
                            'label'   => __( 'Button toggle type', 'aragon_kc_addons' ),
                            'type'    => 'radio',
                            'options' => array(
                                'video-toggle-type-1' => __( 'Video toggle type 1', 'aragon_kc_addons' ),
                                'video-toggle-type-2' => __( 'Video toggle type 2', 'aragon_kc_addons' ),
                                'video-toggle-type-3' => __( 'Video toggle type 3', 'aragon_kc_addons' ),
                            ),
                            'value'   => 'video-toggle-type-1',
                        ),
						array(
							'name'        => 'kc_video_url',
							'label'       => __( 'Video URL', 'aragon_kc_addons' ),
							'type'        => 'text',
							'value'       => 'https://www.youtube.com/embed/KyKgBzFypzc',
						),
					),
					'styles'  => array(
						array(
							'name'  => 'kc_video_box_css',
							'label' => __( 'Styles', 'aragon_kc_addons' ),
							'type'  => 'css',
						)
					)
				)
			),
		)
	);
endif;