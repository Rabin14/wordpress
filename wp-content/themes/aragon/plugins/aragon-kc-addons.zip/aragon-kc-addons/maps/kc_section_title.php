<?php
if ( function_exists( 'kc_add_map' ) ) :
	kc_add_map(
		array(
			'kc_section_title' => array(
				'name'       => __( 'Section title', 'aragon_kc_addons' ),
				'title'      => __( 'Section title', 'aragon_kc_addons' ),
				'admin_view' => __( 'Section title', 'aragon_kc_addons' ),
				'icon'       => 'aragon-title',
				'category'   => 'Aragon-KC-Addons',
				'priority'   => 104,
				'css_box'    => true,
				'params'     => array(
					'general' => array(
						array(
							'name' => 'kc_section_title',
							'label' => __('Section title','aragon_kc_addons'),
							'type' => 'text',
							'value' => 'Section title',
						),
						array(
							'name'    => 'kc_section_subtitle_toggle',
							'label'   => __( 'Subtitle', 'aragon_kc_addons' ),
							'type'    => 'toggle',
							'value'   => 'yes',
							'options' => array( 'yes' => 'Enable' )
						),
						array(
							'name' => 'kc_section_subtitle',
							'label' => __('Section subtitle','aragon_kc_addons'),
							'type' => 'textarea',
							'value' => 'Some text',
							'relation' => array(
								'parent'    => 'kc_section_subtitle_toggle',
								'show_when' => 'yes'
							),
						),
						array(
							'name'    => 'kc_title_type',
							'label'   => __( 'Title type', 'aragon_kc_addons' ),
							'type'    => 'radio',
							'options' => array(
								'color-title' => 'Color title',
								'black-title' => 'Black title',
								'white-title'  => 'White title'
							),
							'value'   => 'color-title',
						)
					),
				),
			),
		)
	);
endif;