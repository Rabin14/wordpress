<?php
if ( function_exists( 'kc_add_map' ) ) :
    kc_add_map(
        array(
            'kc_blockquote' => array(
                'name'       => __( 'Quote', 'aragon_kc_addons' ),
                'title'      => __( 'Quote', 'aragon_kc_addons' ),
                'admin_view' => __( 'Quote', 'aragon_kc_addons' ),
                'icon'       => 'aragon-quote',
                'category'   => 'Aragon-KC-Addons',
                'priority'   => 102,
                'css_box'    => true,
                'params'     => array(
                    'general' => array(
                        array(
                            'name' => 'kc_quote_type',
                            'label' => __('Quote type','aragon_kc_addons'),
                            'type' => 'radio',
                            'options' => array(
                                'blockquote-type-1' => 'Quote type 1',
                                'blockquote-type-2' => 'Quote type 2',
                                'blockquote-type-3' => 'Quote type 3',
                            ),

                            'value' => 'blockquote-type-1',
                        ),
                        array(
                            'name'        => 'kc_quote_text',
                            'label'       => __( 'Quote', 'aragon_kc_addons' ),
                            'type'        => 'text',
                            'value'       => 'Quote',
                        ),
                    ),
                    'styles'  => array(
                        array(
                            'name'  => 'kc_bloquote_css',
                            'label' => __( 'Styles', 'aragon_kc_addons' ),
                            'type'  => 'css',
                        )
                    )
                )
            ),
        )
    );
endif;