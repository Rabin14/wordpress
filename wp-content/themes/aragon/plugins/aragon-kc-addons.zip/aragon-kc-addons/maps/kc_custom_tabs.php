<?php
if ( function_exists( 'kc_add_map' ) ) :
    kc_add_map(
        array(
            'kc_custom_tabs' => array(
                'name'         => __( 'Tabs', 'aragon_kc_addons' ),
                'title'        => __( 'Tabs', 'aragon_kc_addons' ),
                'admin_view'   => __( 'Tabs', 'aragon_kc_addons' ),
                'icon'         => 'aragon-tabs',
                'category'     => 'Aragon-KC-Addons',
                'is_container' => true,
                'priority'     => 101,
                'views'        => array(
                    'type'     => 'views_sections',
                    'sections' => 'kc_custom_tabs_tab',
                    'display'  => 'vertical'
                ),
                'params'       => array(
                    'general' => array(
                        array(
                            'name' => 'kc_tabs_type',
                            'label' => __('Tabs type','aragon_kc_addons'),
                            'type' => 'radio',
                            'options' => array(
                                'tab-type-1' => 'Tabs type 1',
                                'tab-type-2' => 'Tabs type 2',
                                'tab-type-3' => 'Tabs type 3',
                            ),
                            'value' => 'tab-type-1',
                        ),
                    ),
                ),
            ),
        )
    );
endif;
