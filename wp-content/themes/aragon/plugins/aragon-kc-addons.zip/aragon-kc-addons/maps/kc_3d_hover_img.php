<?php
if ( function_exists( 'kc_add_map' ) ) :
	kc_add_map(
		array(
			'kc_3d_hover_img' => array(
				'name'       => __( '3D Hover Image', 'aragon_kc_addons' ),
				'title'      => __( '3D Hover Image', 'aragon_kc_addons' ),
				'admin_view' => __( '3D Hover Image', 'aragon_kc_addons' ),
				'icon'       => 'aragon-3d-img',
				'category'   => 'Aragon-KC-Addons',
				'priority'   => 103,
				'css_box'    => true,
				'params'     => array(
					'general' => array(
						array(
							'name' => 'kc_3d_hover_img',
							'label' => __('3D Hover Image','aragon_kc_addons'),
							'type' => 'attach_image',
						),
					),
					'styles'  => array(
						array(
							'name'  => 'kc_3d_hover_img_styles',
							'label' => __( 'Styles', 'aragon_kc_addons' ),
							'type'  => 'css',
						)
					)
				)
			),
		)
	);
endif;