<?php
if ( function_exists( 'kc_add_map' ) ) :
    if ( class_exists( 'kc_tools' ) ) {
        $forms = kc_tools::get_cf7_names();
    } else {
        $forms = '';
    }

    if ( function_exists( 'kc_add_map' ) ) {
        kc_add_map(
            array(
                'kc_custom_contact_form' => array(
                    'name'        => __( 'Contact Form 7', 'aragon_kc_addons' ),
                    'title'       => __( 'Contact Form 7', 'aragon_kc_addons' ),
                    'description' => __( 'Contact Form 7', 'aragon_kc_addons' ),
                    'icon'        => 'aragon-contact',
                    'category'   => 'Aragon-KC-Addons',
                    'priority'   => 104,
                    'css_box'     => true,
                    'params'      => array(
                        'general' => array(
                            array(
                                'name'    => 'form',
                                'label'   => __( 'Select Form', 'aragon_kc_addons' ),
                                'type'    => 'select',
                                'options' => $forms
                            ),

                        ),
                        'styles'  => array(
                            array(
                                'name'  => 'kc_custom_contact_form_css',
                                'label' => __( 'Styles', 'aragon_kc_addons' ),
                                'type'  => 'css',
                            )
                        )
                    )
                )
            )
        );


    }
endif;