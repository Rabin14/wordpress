<?php
if ( function_exists( 'kc_add_map' ) ) :
	kc_add_map(
		array(
			'kc_team_grid_item' => array(
				'name'       => __( 'Member', 'aragon_kc_addons' ),
				'title'      => __( 'Member', 'aragon_kc_addons' ),
				'admin_view' => __( 'Member', 'aragon_kc_addons' ),
				'icon'       => 'aragon-team',
				'category'   => 'Aragon-KC-Addons',
				'priority'   => 104,
				'css_box'    => true,
				'params'     => array(
					'general' => array(
						array(
							'name'    => 'kc_member_type',
							'label'   => __( 'Select a member type', 'aragon_kc_addons' ),
							'type'    => 'radio',
							'options' => array(
								'team-member-type-1' => 'Member type 1',
								'team-member-type-2' => 'Member type 2',
								'team-member-type-3' => 'Member type 3',
							),
							'value'   => 'team-member-type-1'
						),
						array(
							'name'        => 'kc_member_image',
							'label'       => __( 'Member image', 'aragon_kc_addons' ),
							'type'        => 'attach_image',
						),
						array(
							'name'        => 'kc_member_name',
							'label'       => __( 'Member name', 'aragon_kc_addons' ),
							'type'        => 'text',
							'value'       => 'Jonathan Doe',
						),
						array(
							'name'        => 'kc_member_position',
							'label'       => __( 'Member position', 'aragon_kc_addons' ),
							'type'        => 'text',
							'value'       => 'Designer',
						),
						array(
							'name'        => 'kc_social_toggle',
							'type'        => 'toggle',
							'label'       => __( 'Enable social networks?', 'aragon_kc_addons' ),
							'options'     => array( 'yes' => 'Yes, Please!' )
						),
						array(
							'name'        => 'kc_member_social_group',
							'type'        => 'group',
							'label'       => __( 'Social networks', 'aragon_kc_addons' ),
							'options'     => array( 'add_network' => __( 'Add new network', 'aragon_kc_addons' ) ),
							'relation'    => array(
								'parent'    => 'kc_social_toggle',
								'show_when' => 'yes'
							),
							'params'      => array(
								array(
									'name'  => 'kc_social_icon',
									'label' => __( 'Social network icon', 'aragon_kc_addons' ),
									'type'  => 'icon_picker',
								),
								array(
									'name'  => 'kc_social_color',
									'label' => __( 'Social network color', 'aragon_kc_addons' ),
									'type'  => 'color_picker',
								),
								array(
									'name'        => 'kc_team_link',
									'label'       => __( 'Social network link', 'aragon_kc_addons' ),
									'type'        => 'text',
								)
							)
						),
					),
					'styles'  => array(
						array(
							'name'  => 'kc_team_grid_css',
							'label' => __( 'Styles', 'aragon_kc_addons' ),
							'type'  => 'css',
						)
					)
				)
			),
		)
	);
endif;
