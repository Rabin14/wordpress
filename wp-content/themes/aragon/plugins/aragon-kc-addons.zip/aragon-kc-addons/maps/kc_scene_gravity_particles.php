<?php
if ( function_exists( 'kc_add_map' ) ) :
	kc_add_map(
		array(
			'kc_scene_gravity_particles' => array(
				'name'       => __( 'Scene Particles Gravity', 'aragon_kc_addons' ),
				'title'      => __( 'Scene Particles Gravity', 'aragon_kc_addons' ),
				'admin_view' => __( 'Scene Particles Gravity', 'aragon_kc_addons' ),
				'icon'       => 'aragon-canvas',
				'category'   => 'Aragon-KC-Addons',
				'priority'   => 105,
				'css_box'    => true,
				'params'     => array(

				)
			),
		)
	);
endif;
