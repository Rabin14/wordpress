<?php
if ( function_exists( 'kc_add_map' ) ) :
	kc_add_map(
		array(
			'kc_aragon_buttons' => array(
				'name'       => __( 'Button', 'aragon_kc_addons' ),
				'title'      => __( 'Button', 'aragon_kc_addons' ),
				'admin_view' => __( 'Button', 'aragon_kc_addons' ),
				'icon'       => 'aragon-button',
				'category'   => 'Aragon-KC-Addons',
				'priority'   => 102,
				'css_box'    => true,
				'params'     => array(
					'general' => array(
						array(
							'name'    => 'kc_button_alignment',
							'label'   => __( 'Align button', 'aragon_kc_addons' ),
							'type'    => 'radio',
							'options' => array(
								'justify-content-start'  => 'Left',
								'justify-content-center' => 'Center',
								'justify-content-end'    => 'Right',
							),
							'value'   => 'justify-content-start',
						),
						array(
							'type'    => 'group',
							'label'   => __( 'Button', 'aragon_kc_addons' ),
							'name'    => 'kc_buttons_group',
							'options' => array( 'add_button' => __( 'Add new button', 'aragon_kc_addons' ) ),
							'params'  => array(
								array(
									'name'    => 'kc_button_type',
									'label'   => __( 'Button type', 'aragon_kc_addons' ),
									'type'    => 'radio',
									'options' => array(
										'btn-gradient-type-1' => 'Gradient Button Type 1',
										'btn-gradient-type-2' => 'Gradient Button Type 2',
										'btn-simple-type-1' => 'Simple Button Type 1',
										'btn-simple-type-2' => 'Simple Button Type 2',
										'btn-white-type-1' => 'White Button Type 1',
										'btn-black-type-1' => 'Black Button Type 1',
									),
									'value'   => 'btn-gradient-type-1',
								),
								array(
									'name'        => 'kc_button_link',
									'label'       => __( 'Button link', 'aragon_kc_addons' ),
									'type'        => 'link',
									'description' => __( 'Enter button link', 'aragon_kc_addons' ),
								),
								array(
									'name'    => 'kc_button_icon_toggle',
									'label'   => __( 'Button icon', 'aragon_kc_addons' ),
									'type'    => 'toggle',
									'value'   => 'yes',
									'options' => array( 'yes' => 'Enable' )
								),
								array(
									'name'  => 'kc_button_icon',
									'label' => __( 'Select icon', 'aragon_kc_addons' ),
									'type'  => 'icon_picker',
									'relation' => array(
										'parent'    => 'kc_buttons_group-kc_button_icon_toggle',
										'show_when' => 'yes'
									),
								),
								array(
									'name'    => 'kc_button_icon_alignment',
									'label'   => __( 'Icon button alignment', 'aragon_kc_addons' ),
									'type'    => 'radio',
									'options' => array(
										'right-icon' => 'Right',
										'left-icon'  => 'Left'
									),
									'value'   => 'right-icon',
									'relation' => array(
										'parent'    => 'kc_buttons_group-kc_button_icon_toggle',
										'show_when' => 'yes'
									),
								)
							)
						),
					),
					'styles'  => array(
						array(
							'name'  => 'kc_aragon_button_styles',
							'label' => __( 'Styles', 'aragon_kc_addons' ),
							'type'  => 'css',
						)
					)
				),
			),
		)
	);
endif;