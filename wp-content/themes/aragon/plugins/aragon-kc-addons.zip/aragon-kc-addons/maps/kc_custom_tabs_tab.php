<?php
if ( function_exists( 'kc_add_map' ) ) :
    kc_add_map(
        array(
            'kc_custom_tabs_tab' => array(
                'name'       => __( 'Tab', 'aragon_kc_addons' ),
                'title'      => __( 'Tab', 'aragon_kc_addons' ),
                'admin_view' => __( 'Tab', 'aragon_kc_addons' ),
                'category'   => '',
                'priority'   => 102,
                'is_container' => true,
                'system_only' => true,
                'css_box'    => true,
                'params'     => array(
                    'general' => array(
                        array(
                            'name' => 'kc_tab_title',
                            'label' => __('Tab title','aragon_kc_addons'),
                            'type' => 'text',
                            'value' => 'Tab title',
                        ),
                    ),
                )
            ),
        )
    );
endif;