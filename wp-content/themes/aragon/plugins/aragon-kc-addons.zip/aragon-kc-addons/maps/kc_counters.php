<?php
if (function_exists('kc_add_map')) :
    kc_add_map(
        array(
            'kc_counters' => array(
                'name' => __('Counters', 'aragon_kc_addons'),
                'title' => __('Counters', 'aragon_kc_addons'),
                'admin_view' => __('Counters', 'aragon_kc_addons'),
                'icon' => 'aragon-counters',
                'category' => 'Aragon-KC-Addons',
                'priority' => 102,
                'css_box' => true,
                'params' => array(
                    'general' => array(
                        array(
                            'name' => 'kc_counters_type',
                            'label' => __('Counters type', 'aragon_kc_addons'),
                            'type' => 'radio',
                            'options' => array(
                                'counters-type-1' => __('Counters Type 1', 'aragon_kc_addons'),
                                'counters-type-2' => __('Counters Type 2 [Background Image]', 'aragon_kc_addons'),
                                'counters-type-3' => __('Counters Type 3', 'aragon_kc_addons'),
                            ),
                            'value' => 'counters-type-1',
                        ),
                        array(
                            'name' => 'kc_counters',
                            'type' => 'group',
                            'label' => __('Counters', 'aragon_kc_addons'),
                            'options' => array('add_counter' => __('Add new counter', 'aragon_kc_addons')),
                            'params' => array(
                                array(
                                    'name' => 'kc_counter_title',
                                    'label' => __('Counter title', 'aragon_kc_addons'),
                                    'type' => 'text',
                                    'value' => 'PROJECT DONE',
                                ),
                                array(
                                    'name' => 'kc_counter_count',
                                    'label' => __('Count', 'aragon_kc_addons'),
                                    'type' => 'number_slider',
                                    'options' => array(
                                        'min' => 0,
                                        'max' => 10000,
                                        'show_input' => true
                                    ),
                                    'value' => '128',
                                ),
                                array(
                                    'name' => 'kc_counter_icon_toggle',
                                    'label' => __('Counter Icon', 'aragon_kc_addons'),
                                    'type' => 'toggle',
                                    'value' => 'yes',
                                    'options' => array('yes' => 'Enable')
                                ),
                                array(
                                    'name' => 'kc_counter_icon',
                                    'label' => __('Icon', 'aragon_kc_addons'),
                                    'type' => 'icon_picker',
                                    'relation' => array(
                                        'parent' => 'kc_counters-kc_counter_icon_toggle',
                                        'show_when' => 'yes'
                                    ),
                                ),
                                array(
                                    'name' => 'kc_counter_bg',
                                    'label' => __('Background image', 'aragon_kc_addons'),
                                    'type' => 'attach_image',
                                    'description' => __('Only for "Counters Type 2 [Background Image]"', 'aragon_kc_addons')
                                ),
                            )
                        )
                    ),
                    'styles' => array(
                        array(
                            'name' => 'kc_counters_styles',
                            'label' => __('Styles', 'aragon_kc_addons'),
                            'type' => 'css',
                        )
                    )
                )
            ),
        )
    );
endif;