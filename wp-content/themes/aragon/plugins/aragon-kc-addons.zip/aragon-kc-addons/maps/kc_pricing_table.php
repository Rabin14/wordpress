<?php
if ( function_exists( 'kc_add_map' ) ) :
    kc_add_map(
        array(
            'kc_pricing_table' => array(
                'name'       => __( 'Pricing table', 'aragon_kc_addons' ),
                'title'      => __( 'Pricing table', 'aragon_kc_addons' ),
                'admin_view' => __( 'Pricing table', 'aragon_kc_addons' ),
                'icon'       => 'aragon-pricing-table',
                'category'   => 'Aragon-KC-Addons',
                'priority'   => 102,
                'css_box'    => true,
                'params'     => array(
                    'general' => array(
                        array(
                            'name'    => 'kc_pricing_table_type',
                            'label'   => __( 'Type of pricing table', 'aragon_kc_addons' ),
                            'type'    => 'radio',
                            'options' => array(
                                'pricing-table-type-1' => 'Pricing table type 1',
                            ),
                            'value'   => 'pricing-table-type-1'
                        ),
                        array(
                            'name'        => 'kc_main_table_toggle',
                            'label'       => __( 'Main plan', 'aragon_kc_addons' ),
                            'type'        => 'toggle',
                            'options'     => array( 'yes' => 'Yes, Please!' ),
                        ),
                        array(
                            'name'        => 'kc_pricing_plan',
                            'label'       => __( 'Pricing plan', 'aragon_kc_addons' ),
                            'type'        => 'text',
                        ),
                        array(
                            'name'        => 'kc_pricing_symbol',
                            'label'       => __( 'Currency symbol', 'aragon_kc_addons' ),
                            'type'        => 'text',
                        ),
                        array(
                            'name'        => 'kc_plan_cost',
                            'label'       => __( 'Cost of the plan', 'aragon_kc_addons' ),
                            'type'        => 'text',
                        ),
                        array(
                            'name' => 'kc_plan_icon',
                            'label' => __('Plan icon','aragon_kc_addons'),
                            'type' => 'icon_picker',
                        ),
                        array(
                            'name'        => 'kc_features_group',
                            'type'        => 'group',
                            'label'       => __( 'Features', 'aragon_kc_addons' ),
                            'options'     => array( 'add_feature' => __( 'Add new feature', 'aragon_kc_addons' ) ),
                            'params'      => array(
                                array(
                                    'name'        => 'kc_feature_title',
                                    'label'       => __( 'Feature title', 'aragon_kc_addons' ),
                                    'type'        => 'text',
                                    'value'       => 'Feature title',
                                    'description' => __( 'Enter the feature title', 'aragon_kc_addons' ),
                                ),
                            )
                        ),
                        array(
                            'name'        => 'kc_plan_button',
                            'type'        => 'toggle',
                            'label'       => __( 'Enable button?', 'aragon_kc_addons' ),
                            'options'     => array( 'yes' => 'Yes, Please!' )
                        ),
                        array(
                            'name'        => 'kc_button_link',
                            'label'       => __( 'Button link', 'aragon_kc_addons' ),
                            'type'        => 'link',
                            'relation'    => array(
                                'parent'    => 'kc_plan_button',
                                'show_when' => 'yes'
                            )
                        ),
                    ),
                    'styles'  => array(
                        array(
                            'name'  => 'kc_pricing_tables_css',
                            'label' => __( 'Styles', 'aragon_kc_addons' ),
                            'type'  => 'css',
                        )
                    )
                )
            ),
        )
    );
endif;