<?php
if ( function_exists( 'kc_add_map' ) ) :
	kc_add_map(
		array(
			'kc_progress_bars' => array(
				'name'       => __( 'Progress bars', 'aragon_kc_addons' ),
				'title'      => __( 'Progress bars', 'aragon_kc_addons' ),
				'admin_view' => __( 'Progress bars', 'aragon_kc_addons' ),
				'icon'       => 'aragon-progress-bars',
				'category'   => 'Aragon-KC-Addons',
				'priority'   => 102,
				'css_box'    => true,
				'params'     => array(
					'general' => array(
						array(
							'name'    => 'kc_progress_bar_type',
							'label'   => __( 'Progress bar type', 'aragon_kc_addons' ),
							'type'    => 'radio',
							'options' => array(
								'progress-bar-type-1' => 'Progress bar type 1',
								'progress-bar-type-2' => 'Progress bar type 2',
							),

							'value'       => 'progress-bar-type-1',
							'description' => __( 'Select a progress bar type', 'aragon_kc_addons' ),
						),
						array(
							'name'    => 'kc_progress_bars_group',
							'type'    => 'group',
							'label'   => __( 'Progress bars', 'aragon_kc_addons' ),
							'options' => array( 'add_bar' => __( 'Add new progress bar', 'aragon_kc_addons' ) ),
							'params'  => array(
								array(
									'name'  => 'kc_progress_bar_title',
									'label' => __( 'Progress bar title', 'aragon_kc_addons' ),
									'type'  => 'text',
								),
								array(
									'name'    => 'kc_progress_bar_value',
									'label'   => __( 'Value', 'aragon_kc_addons' ),
									'type'    => 'number_slider',
									'options' => array(
										'min'        => 0,
										'max'        => 100,
										'show_input' => true
									),
								)
							)
						),
					),
					'styles'  => array(
						array(
							'name'  => 'kc_accordions_css',
							'label' => __( 'Styles', 'aragon_kc_addons' ),
							'type'  => 'css',
						)
					)
				)
			),

		)
	);
endif;