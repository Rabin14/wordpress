<?php
if ( function_exists( 'kc_add_map' ) ) :
	kc_add_map(
		array(
			'kc_hero_slider_slide' => array(
				'name'       => __( 'Slide', 'aragon_kc_addons' ),
				'title'      => __( 'Slide', 'aragon_kc_addons' ),
				'admin_view' => __( 'Slide', 'aragon_kc_addons' ),
				'category'   => '',
				'priority'   => 102,
				'is_container' => true,
				'system_only' => true,
				'css_box'    => true,
				'params'     => array(
					'general' => array(
						array(
							'name' => 'kc_slide_bg',
							'label' => __('Background Image'),
							'type' => 'attach_image',
						),
                        array(
                            'name'    => 'kc_hero_slide_overlay',
                            'label'   => __( 'Overlay', 'aragon_kc_addons' ),
                            'type'    => 'toggle',
                            'value'   => 'yes',
                            'options' => array( 'yes' => 'Enable' )
                        ),
					),
				)
			),
		)
	);
endif;