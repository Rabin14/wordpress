<?php
if (function_exists('kc_add_map')) :
    kc_add_map(
        array(
            'kc_clients_grid_item' => array(
                'name' => __('Client', 'aragon_kc_addons'),
                'title' => __('Client', 'aragon_kc_addons'),
                'admin_view' => __('Client', 'aragon_kc_addons'),
                'icon' => 'aragon-clients',
                'category' => 'Aragon-KC-Addons',
                'priority' => 104,
                'css_box' => true,
                'params' => array(
                    'general' => array(
                        array(
                            'name' => 'kc_client_type',
                            'label' => __('Select a clients grid item type', 'aragon_kc_addons'),
                            'type' => 'radio',
                            'options' => array(
                                'clients-grid-item-type-1' => 'Client type 1',
                            ),
                            'value' => 'clients-grid-item-type-1'
                        ),
                        array(
                            'name' => 'kc_client_bg_image',
                            'label' => __('Client background image', 'aragon_kc_addons'),
                            'type' => 'attach_image',
                            'relation' => array(
                                'parent' => 'kc_client_type',
                                'show_when' => 'clients-grid-item-type-1'
                            ),
                        ),
                        array(
                            'name' => 'kc_client_image',
                            'label' => __('Client logo', 'aragon_kc_addons'),
                            'type' => 'attach_image',
                        ),
                        array(
                            'name' => 'kc_client_content',
                            'label' => __('Client content'),
                            'type' => 'textarea',
                            'value' => 'Some content',
                        ),
                    ),
                    'styles' => array(
                        array(
                            'name' => 'kc_clients_grid_css',
                            'label' => __('Styles', 'aragon_kc_addons'),
                            'type' => 'css',
                        )
                    )
                )
            ),
        )
    );
endif;
