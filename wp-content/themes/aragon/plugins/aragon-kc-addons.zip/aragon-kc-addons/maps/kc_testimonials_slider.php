<?php
if ( function_exists( 'kc_add_map' ) ) :
    kc_add_map(
        array(
            'kc_testimonials_slider' => array(
                'name'       => __( 'Testimonials slider', 'aragon_kc_addons' ),
                'title'      => __( 'Testimonials slider', 'aragon_kc_addons' ),
                'admin_view' => __( 'Testimonials slider', 'aragon_kc_addons' ),
                'icon'       => 'aragon-testimonials',
                'category'   => 'Aragon-KC-Addons',
                'priority'   => 104,
                'css_box'    => true,
                'params'     => array(
                    'general' => array(
                        array(
                            'name' => 'kc_testimonials_type',
                            'label' => __('Testimonials slider type','aragon_kc_addons'),
                            'type' => 'radio',
                            'options' => array(
                                'testimonials-slider-type-1' => 'Testimonials slider type 1',
                                'testimonials-slider-type-2' => 'Testimonials slider type 2',
                            ),
                            'value' => 'testimonials-slider-type-1',
                        ),
                        array(
                            'name'        => 'kc_review_group',
                            'type'        => 'group',
                            'label'       => __( 'Reviews', 'aragon_kc_addons' ),
                            'options'     => array( 'add_review' => __( 'Add new review', 'aragon_kc_addons' ) ),
                            'params'      => array(
                                array(
                                    'name'  => 'kc_person_image',
                                    'label' => __( 'Upload an image of a person', 'aragon_kc_addons' ),
                                    'type'  => 'attach_image',
                                ),
                                array(
                                    'name'        => 'kc_person_name',
                                    'label'       => __( 'Person name', 'aragon_kc_addons' ),
                                    'type'        => 'text',
                                    'value'       => 'Jonathan Doe',
                                ),
                                array(
                                    'name'        => 'kc_person_position',
                                    'label'       => __( 'Person position', 'aragon_kc_addons' ),
                                    'type'        => 'text',
                                    'value'       => 'Designer',
                                ),
                                array(
                                    'name'        => 'kc_review',
                                    'label'       => __( 'Review', 'aragon_kc_addons' ),
                                    'type'        => 'textarea',
                                    'value'       => 'Review body',
                                ),
                                array(
                                    'name' => 'kc_count_star',
                                    'label' => __('Number of stars','aragon_kc_addons'),
                                    'type' => 'number_slider',
                                    'options' => array(
                                        'min' => 1,
                                        'max' => 5,
                                        'show_input' => true
                                    ),
                                ),
                            ),
                        )
                    ),
                    'styles'  => array(
                        array(
                            'name'  => 'kc_testimonials_slider_css',
                            'label' => __( 'Styles', 'aragon_kc_addons' ),
                            'type'  => 'css',
                        )
                    )
                )
            ),
        )
    );
endif;
