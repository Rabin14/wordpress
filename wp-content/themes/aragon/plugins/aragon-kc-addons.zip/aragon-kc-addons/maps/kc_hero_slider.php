<?php
if ( function_exists( 'kc_add_map' ) ) :
	kc_add_map(
		array(
			'kc_hero_slider' => array(
				'name'         => __( 'Hero Slider', 'aragon_kc_addons' ),
				'title'        => __( 'Hero Slider', 'aragon_kc_addons' ),
				'admin_view'   => __( 'Hero Slider', 'aragon_kc_addons' ),
				'icon'         => 'aragon-hero-header',
				'category'     => 'Aragon-KC-Addons',
				'is_container' => true,
				'priority'     => 101,
				'views'        => array(
					'type'     => 'views_sections',
					'sections' => 'kc_hero_slider_slide',
					'display'  => 'vertical'
				),
				'params'       => array(
					'general' => array(
						array(
							'name' => 'kc_hero_height',
							'label' => __('Hero Slider height','aragon_kc_addons'),
							'type' => 'number_slider',
							'options' => array(
								'min' => 40,
								'max' => 100,
								'unit' => 'vh',
								'show_input' => true
							),
						),
                        array(
                            'name'    => 'kc_scroll_down',
                            'label'   => __( 'Scroll down icon', 'aragon_kc_addons' ),
                            'type'    => 'toggle',
                            'value'   => 'yes',
                            'options' => array( 'yes' => 'Enable' )
                        ),
					),
				),
			),
		)
	);
endif;
