<?php
if ( function_exists( 'kc_add_map' ) ) :
    kc_add_map(
        array(
            'kc_social_icons' => array(
                'name'       => __( 'Social Icons', 'aragon_kc_addons' ),
                'title'      => __( 'Social Icons', 'aragon_kc_addons' ),
                'admin_view' => __( 'Social Icons', 'aragon_kc_addons' ),
                'icon'       => 'aragon-social',
                'category'   => 'Aragon-KC-Addons',
                'priority'   => 103,
                'css_box'    => true,
                'params'     => array(
                    'general' => array(
                        array(
                            'name'        => 'kc_networks_alignment',
                            'label'       => __( 'Align button', 'aragon_kc_addons' ),
                            'type'        => 'radio',
                            'options'     => array(
                                'justify-content-start'  => 'Left',
                                'justify-content-center' => 'Center',
                                'justify-content-end'    => 'Right',
                            ),
                            'value'       => 'justify-content-start',
                            'description' => __( 'Select the networks alignment', 'aragon_kc_addons' ),
                        ),
                        array(
                            'name'        => 'kc_network_type',
                            'label'       => __( 'Social icons type', 'aragon_kc_addons' ),
                            'type'        => 'radio',
                            'options'     => array(
                                'social-icons-type-1' => 'Social icons type 1',
                                'social-icons-type-2' => 'Social icons type 2',
                                'social-icons-type-3' => 'Social icons type 3'
                            ),
                            'value'       => 'social-icons-type-1',
                        ),
                        array(
                            'name'        => 'kc_networks_group',
                            'type'        => 'group',
                            'label'       => __( 'Social networks', 'aragon_kc_addons' ),
                            'options'     => array( 'add_network' => __( 'Add new network', 'aragon_kc_addons' ) ),
                            'params'      => array(
                                array(
                                    'name'        => 'kc_network_link',
                                    'label'       => __( 'Network link', 'aragon_kc_addons' ),
                                    'type'        => 'text',
                                ),
                                array(
                                    'name'  => 'kc_network_icon',
                                    'label' => __( 'Network icon', 'aragon_kc_addons' ),
                                    'type'  => 'icon_picker',
                                ),
                                array(
                                    'name'  => 'kc_network_background',
                                    'label' => __( 'Background color', 'aragon_kc_addons' ),
                                    'type'  => 'color_picker',
                                ),
                                array(
                                    'name'  => 'kc_network_icon_color',
                                    'label' => __( 'Icon color', 'aragon_kc_addons' ),
                                    'type'  => 'color_picker',
                                ),
                            )
                        ),
                    ),
                    'styles'  => array(
                        array(
                            'name'  => 'kc_social_icons_css',
                            'label' => __( 'Styles', 'aragon_kc_addons' ),
                            'type'  => 'css',
                        )
                    )
                )
            ),
        )
    );
endif;
