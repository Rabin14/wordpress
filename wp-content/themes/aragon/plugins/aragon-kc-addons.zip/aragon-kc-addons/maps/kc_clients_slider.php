<?php
if ( function_exists( 'kc_add_map' ) ) :
	kc_add_map(
		array(
			'kc_clients_slider' => array(
				'name'       => __( 'Clients slider', 'aragon_kc_addons' ),
				'title'      => __( 'Clients slider', 'aragon_kc_addons' ),
				'admin_view' => __( 'Clients slider', 'aragon_kc_addons' ),
				'icon'       => 'aragon-clients-slider',
				'category'   => 'Aragon-KC-Addons',
				'priority'   => 104,
				'css_box'    => true,
				'params'     => array(
					'general' => array(
                        array(
                            'name'    => 'kc_clients_type',
                            'label'   => __( 'Clients slider type', 'aragon_kc_addons' ),
                            'type'    => 'radio',
                            'options' => array(
                                'clients-slider-type-1' => 'Clients slider Type 1',
                                'clients-slider-type-2' => 'Clients slider Type 2',
                            ),
                            'value'   => 'clients-slider-type-1',
                        ),
						array(
							'name'        => 'kc_clients_group',
							'type'        => 'group',
							'label'       => __( 'Clients', 'aragon_kc_addons' ),
							'options'     => array( 'add_member' => __( 'Add new member', 'aragon_kc_addons' ) ),
							'params'      => array(
								array(
									'name'        => 'kc_client_image',
									'label'       => __( 'Client image', 'aragon_kc_addons' ),
									'type'        => 'attach_image',
								),
							)
						),
					),
					'styles'  => array(
						array(
							'name'  => 'kc_clients_slider_styles',
							'label' => __( 'Styles', 'aragon_kc_addons' ),
							'type'  => 'css',
						)
					)
				)
			),
		)
	);
endif;