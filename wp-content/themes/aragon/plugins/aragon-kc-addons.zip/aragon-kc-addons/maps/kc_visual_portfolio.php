<?php
if ( function_exists( 'kc_add_map' ) ) :
	$vp_query = get_posts(
		array(
			'post_type'      => 'vp_lists',
			'posts_per_page' => - 1,
			'showposts'      => - 1,
			'paged'          => - 1,
		)
	);
	$data_vc  = array();
	foreach ( $vp_query as $post ) {
		$data_vc[ $post->ID ] = $post->post_title;
	}
	if ( function_exists( 'kc_add_map' ) ) {
		kc_add_map(
			array(
				'kc_visual_portfolio' => array(
					'name'        => __( 'Visual Portfolio', 'aragon_kc_addons' ),
					'title'       => __( 'Visual Portfolio', 'aragon_kc_addons' ),
					'admin_view'  => __( 'Visual Portfolio', 'aragon_kc_addons' ),
					'description' => __( 'Visual Portfolio', 'aragon_kc_addons' ),
					'icon'        => 'aragon-portfolio',
					'category'    => 'Aragon-KC-Addons',
					'priority'    => 101,
					'css_box'     => true,
					'params'      => array(
						'general' => array(
							array(
								'name'    => 'vp_id',
								'label'   => __( 'Select Portfolio Layout', 'aragon_kc_addons' ),
								'type'    => 'select',
								'options' => $data_vc
							),
						),
						'styles'  => array(
							array(
								'name'  => 'kc_portfolio_styles',
								'label' => __( 'Styles', 'aragon_kc_addons' ),
								'type'  => 'css',
							)
						)
					)
				)
			)
		);
	}
endif;