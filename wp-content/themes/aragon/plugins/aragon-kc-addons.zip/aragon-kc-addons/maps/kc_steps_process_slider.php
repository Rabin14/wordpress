<?php
if ( function_exists( 'kc_add_map' ) ) :
	kc_add_map(
		array(
			'kc_steps_process_slider' => array(
				'name'       => __( 'Steps', 'aragon_kc_addons' ),
				'title'      => __( 'Steps', 'aragon_kc_addons' ),
				'admin_view' => __( 'Steps', 'aragon_kc_addons' ),
				'icon'       => 'aragon-steps',
				'category'   => 'Aragon-KC-Addons',
				'priority'   => 104,
				'css_box'    => true,
				'params'     => array(
					'general' => array(
                        array(
                            'name' => 'kc_steps_type',
                            'label' => __('Steps slider type','aragon_kc_addons'),
                            'type' => 'radio',
                            'options' => array(
                                'steps-slider-type-1' => 'Steps slider type 1',
                                'steps-slider-type-2' => 'Steps slider type 2',
                            ),
                            'value' => 'steps-slider-type-1',
                        ),
						array(
							'name'    => 'kc_steps_process_group',
							'type'    => 'group',
							'label'   => __( 'Steps', 'aragon_kc_addons' ),
							'options' => array( 'add_step' => __( 'Add new step', 'aragon_kc_addons' ) ),
							'params'  => array(
								array(
									'name'  => 'kc_step_title',
									'label' => __( 'Step title', 'aragon_kc_addons' ),
									'type'  => 'text',
									'value' => 'Step title',
								),
								array(
									'name'  => 'kc_step_body',
									'label' => __( 'Step body', 'aragon_kc_addons' ),
									'type'  => 'textarea',
									'value' => 'Step body',
								),
								array(
									'name' => 'kc_step_background_icon',
									'label' => __('Background icon','aragon_kc_addons'),
									'type' => 'icon_picker',
								),
							)
						),
					),
					'styles'  => array(
						array(
							'name'  => 'kc_steps_css',
							'label' => __( 'Styles', 'aragon_kc_addons' ),
							'type'  => 'css',
						)
					)
				)
			),
		)
	);
endif;