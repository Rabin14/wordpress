<?php
if ( function_exists( 'kc_add_map' ) ) :
	kc_add_map(
		array(
			'kc_list' => array(
				'name'       => __( 'List', 'aragon_kc_addons' ),
				'title'      => __( 'List', 'aragon_kc_addons' ),
				'admin_view' => __( 'List', 'aragon_kc_addons' ),
				'icon'       => 'aragon-list',
				'category'   => 'Aragon-KC-Addons',
				'priority'   => 102,
				'css_box'    => true,
				'params'     => array(
					'general' => array(
						array(
							'name' => 'kc_list_type',
							'label' => __('List type','aragon_kc_addons'),
							'type' => 'radio',
							'options' => array(
								'list-type-1' => 'List type 1',
								'list-type-2' => 'List type 2',
								'list-type-3' => 'List type 3',
							),

							'value' => 'list-type-1',
						),
						array(
							'name'        => 'kc_lists_group',
							'type'        => 'group',
							'label'       => __( 'List group', 'aragon_kc_addons' ),
							'options'     => array( 'add_list' => __( 'Add new list item', 'aragon_kc_addons' ) ),
							'params'      => array(
								array(
									'name'        => 'kc_list_title',
									'label'       => __( 'List title', 'aragon_kc_addons' ),
									'type'        => 'text',
									'value'       => 'List title',
								),
							)
						),
					),
					'styles'  => array(
						array(
							'name'  => 'kc_lists_css',
							'label' => __( 'Styles', 'aragon_kc_addons' ),
							'type'  => 'css',
						)
					)
				)
			),
		)
	);
endif;