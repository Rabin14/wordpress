<?php
if ( function_exists( 'kc_add_map' ) ) :
    kc_add_map(
        array(
            'kc_custom_accordions_accordion' => array(
                'name'       => __( 'Accordion', 'aragon_kc_addons' ),
                'title'      => __( 'Accordion', 'aragon_kc_addons' ),
                'admin_view' => __( 'Accordion', 'aragon_kc_addons' ),
                'category'   => '',
                'priority'   => 102,
                'is_container' => true,
                'system_only' => true,
                'css_box'    => true,
                'params'     => array(
                    'general' => array(
                        array(
                            'name' => 'kc_accordion_title',
                            'label' => __('Accordion title','aragon_kc_addons'),
                            'type' => 'text',
                            'value' => 'Accordion title',
                        ),
                        array(
                            'name'        => 'kc_accordion_active',
                            'type'        => 'toggle',
                            'label'       => __( 'Active', 'aragon_kc_addons' ),
                            'options'     => array( 'yes' => 'Yes, Please!' )
                        ),
                    ),
                )
            ),
        )
    );
endif;