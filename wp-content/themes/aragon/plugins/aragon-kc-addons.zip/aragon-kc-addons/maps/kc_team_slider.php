<?php
if ( function_exists( 'kc_add_map' ) ) :
    kc_add_map(
        array(
            'kc_team_slider' => array(
                'name'       => __( 'Team slider', 'aragon_kc_addons' ),
                'title'      => __( 'Team slider', 'aragon_kc_addons' ),
                'admin_view' => __( 'Team slider', 'aragon_kc_addons' ),
                'icon'       => 'aragon-team-slider',
                'category'   => 'Aragon-KC-Addons',
                'priority'   => 104,
                'css_box'    => true,
                'params'     => array(
                    'general' => array(
                        array(
                            'name' => 'kc_team_slider_type',
                            'label' => __('List type','aragon_kc_addons'),
                            'type' => 'radio',
                            'options' => array(
                                'team-slider-type-1' => 'Team Slider type 1',
                            ),
                            'value' => 'team-slider-type-1',
                        ),
                        array(
                            'name'        => 'kc_members_group',
                            'type'        => 'group',
                            'label'       => __( 'Members', 'aragon_kc_addons' ),
                            'options'     => array( 'add_member' => __( 'Add new member', 'aragon_kc_addons' ) ),
                            'params'      => array(
                                array(
                                    'name'        => 'kc_member_image',
                                    'label'       => __( 'Member image', 'aragon_kc_addons' ),
                                    'type'        => 'attach_image',
                                ),
                                array(
                                    'name'        => 'kc_member_name',
                                    'label'       => __( 'Member name', 'aragon_kc_addons' ),
                                    'type'        => 'text',
                                    'value'       => 'Jonathan Doe',
                                ),
                                array(
                                    'name'        => 'kc_member_position',
                                    'label'       => __( 'Member position', 'aragon_kc_addons' ),
                                    'type'        => 'text',
                                    'value'       => 'Design',
                                    'description' => __( 'Enter the position of the member', 'aragon_kc_addons' ),
                                ),
                                array(
                                    'name'        => 'kc_social_toggle',
                                    'type'        => 'toggle',
                                    'label'       => __( 'Enable social networks?', 'aragon_kc_addons' ),
                                    'options'     => array( 'yes' => 'Yes, Please!' )
                                ),
                                array(
                                    'name'     => 'kc_icon_picker1',
                                    'label'    => __( 'Social icon 1', 'aragon_kc_addons' ),
                                    'type'     => 'icon_picker',
                                    'relation' => array(
                                        'parent'    => 'kc_members_group-kc_social_toggle',
                                        'show_when' => 'yes'
                                    )
                                ),
                                array(
                                    'name'     => 'kc_network_link1',
                                    'label'    => __( 'Link 1', 'aragon_kc_addons' ),
                                    'type'     => 'link',
                                    'relation' => array(
                                        'parent'    => 'kc_members_group-kc_social_toggle',
                                        'show_when' => 'yes'
                                    )
                                ),
                                array(
                                    'name'     => 'kc_icon_picker2',
                                    'label'    => __( 'Social icon 2', 'aragon_kc_addons' ),
                                    'type'     => 'icon_picker',
                                    'relation' => array(
                                        'parent'    => 'kc_members_group-kc_social_toggle',
                                        'show_when' => 'yes'
                                    )
                                ),
                                array(
                                    'name'     => 'kc_network_link2',
                                    'label'    => __( 'Link 2', 'aragon_kc_addons' ),
                                    'type'     => 'link',
                                    'relation' => array(
                                        'parent'    => 'kc_members_group-kc_social_toggle',
                                        'show_when' => 'yes'
                                    )
                                ),
                                array(
                                    'name'     => 'kc_icon_picker3',
                                    'label'    => __( 'Social icon 3', 'aragon_kc_addons' ),
                                    'type'     => 'icon_picker',
                                    'relation' => array(
                                        'parent'    => 'kc_members_group-kc_social_toggle',
                                        'show_when' => 'yes'
                                    )
                                ),
                                array(
                                    'name'     => 'kc_network_link3',
                                    'label'    => __( 'Link 3', 'aragon_kc_addons' ),
                                    'type'     => 'link',
                                    'relation' => array(
                                        'parent'    => 'kc_members_group-kc_social_toggle',
                                        'show_when' => 'yes'
                                    )
                                ),
                                array(
                                    'name'     => 'kc_icon_picker4',
                                    'label'    => __( 'Social icon 4', 'aragon_kc_addons' ),
                                    'type'     => 'icon_picker',
                                    'relation' => array(
                                        'parent'    => 'kc_members_group-kc_social_toggle',
                                        'show_when' => 'yes'
                                    )
                                ),
                                array(
                                    'name'     => 'kc_network_link4',
                                    'label'    => __( 'Link 4', 'aragon_kc_addons' ),
                                    'type'     => 'link',
                                    'relation' => array(
                                        'parent'    => 'kc_members_group-kc_social_toggle',
                                        'show_when' => 'yes'
                                    )
                                ),
                            )
                        )
                    ),
                    'styles'  => array(
                        array(
                            'name'  => 'kc_team_slider_css',
                            'label' => __( 'Styles', 'aragon_kc_addons' ),
                            'type'  => 'css',
                        )
                    )
                )
            ),
        )
    );
endif;