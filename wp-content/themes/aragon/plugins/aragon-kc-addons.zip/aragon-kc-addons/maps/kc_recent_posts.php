<?php
if (function_exists('kc_add_map')) :
    kc_add_map(
        array(
            'kc_recent_posts' => array(
                'name' => __('Recent post', 'aragon_kc_addons'),
                'title' => __('Recent post', 'aragon_kc_addons'),
                'admin_view' => __('Recent post', 'aragon_kc_addons'),
                'icon' => 'aragon-recent-posts',
                'category' => 'Aragon-KC-Addons',
                'priority' => 102,
                'params' => array(
                    array(
                        'name' => 'kc_recent_posts_type',
                        'label' => __('Recent posts type', 'aragon_kc_addons'),
                        'type' => 'radio',
                        'options' => array(
                            'recent-posts-type-1' => 'Recent posts type 1',
                            'recent-posts-type-2' => 'Recent posts type 2',
                            'recent-posts-type-3' => 'Recent posts type 3',
                        ),

                        'value' => 'recent-posts-type-1',
                    ),
                    array(
                        'name' => 'kc_post_count',
                        'label' => __('Number of posts', 'aragon_kc_addons'),
                        'type' => 'number_slider',
                        'value' => 3,
                        'options' => array(
                            'min' => 0,
                            'max' => 6,
                            'unit' => '',
                            'show_input' => true
                        ),
                    ),
                )
            ),
        )
    );
endif;