<?php
if ( function_exists( 'kc_add_map' ) ) :
	kc_add_map(
		array(
			'kc_service' => array(
				'name'       => __( 'Service', 'aragon_kc_addons' ),
				'title'      => __( 'Service', 'aragon_kc_addons' ),
				'admin_view' => __( 'Service', 'aragon_kc_addons' ),
				'icon'       => 'aragon-service',
				'category'   => 'Aragon-KC-Addons',
				'priority'   => 104,
				'css_box'    => true,
				'params'     => array(
					'general' => array(
						array(
							'name'    => 'kc_service_type',
							'label'   => __( 'Service type', 'aragon_kc_addons' ),
							'type'    => 'radio',
							'options' => array(
								'service-type-1' => __( 'Service type 1', 'aragon_kc_addons' ),
								'service-type-2' => __( 'Service type 2', 'aragon_kc_addons' ),
								'service-type-3' => __( 'Service type 3', 'aragon_kc_addons' ),
								'service-type-4' => __( 'Service type 4', 'aragon_kc_addons' ),
								'service-type-5' => __( 'Service type 5', 'aragon_kc_addons' ),
							),
							'value'   => 'service-type-1',
						),
						array(
							'name' => 'kc_service_icon',
							'label' => __('Icon','aragon_kc_addons'),
							'type' => 'icon_picker',
                            'relation' => array(
                                'parent'    => 'kc_service_type',
                                'hide_when' => 'service-type-5'
                            ),
						),
						array(
							'name' => 'kc_service_title',
							'label' => __('Service title','aragon_kc_addons'),
							'type' => 'text',
							'value' => 'Service title',
						),
                        array(
                            'name' => 'kc_service_index',
                            'label' => __('Service index','aragon_kc_addons'),
                            'type' => 'number_slider',
                            'options' => array(
                                'min' => 0,
                                'max' => 100,
                                'show_input' => true
                            ),
                            'relation' => array(
                                'parent'    => 'kc_service_type',
                                'show_when' => 'service-type-5'
                            ),
                        ),
						array(
							'name'        => 'kc_service_text',
							'label'       => __('Service text','aragon_kc_addons'),
							'type'        => 'textarea',
							'value'       => 'Service text',
						)
					),
					'styles'  => array(
						array(
							'name'  => 'kc_aragon_preview_creative_section_styles',
							'label' => __( 'Styles', 'aragon_kc_addons' ),
							'type'  => 'css',
						)
					)
				),
			),
		)
	);
endif;