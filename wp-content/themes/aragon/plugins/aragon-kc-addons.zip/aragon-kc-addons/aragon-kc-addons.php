<?php
/*
Plugin Name: Aragon KC-Addons
Plugin URI: https://themeforest.net/user/jd-themes
Description: Addons for KingComposer
Author: JDThemes
Version: 1.0
License:      GPLv2 or later
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  aragon_kc_addons
*/

add_action( 'init', 'jd_kc_addons_init', 99 );

function jd_kc_addons_init() {
	load_plugin_textdomain( 'aragon_kc_addons', false, basename( dirname( __FILE__ ) ) . '/lang' );
	if ( function_exists( 'kc_add_map' ) ):

		global $kc;
		$kc->add_content_type( array( 'post', 'portfolio' ) );
		$plugin_templates = plugin_dir_path( __FILE__ ) . 'templates/';
		$plugin_maps      = plugin_dir_path( __FILE__ ) . 'maps/';
		$kc->set_template_path( $plugin_templates );
		include_once( $plugin_maps . 'kc_hero_header.php' );
		include_once( $plugin_maps . 'kc_service.php' );
		include_once( $plugin_maps . 'kc_video_box.php' );
		include_once( $plugin_maps . 'kc_counters.php' );
		include_once( $plugin_maps . 'kc_section_title.php' );
		include_once( $plugin_maps . 'kc_progress_bars.php' );
		include_once( $plugin_maps . 'kc_aragon_buttons.php' );
		include_once( $plugin_maps . 'kc_3d_hover_img.php' );
		include_once( $plugin_maps . 'kc_steps_process_slider.php' );
		include_once( $plugin_maps . 'kc_visual_portfolio.php' );
		include_once( $plugin_maps . 'kc_clients_slider.php' );
		include_once( $plugin_maps . 'kc_team_grid_item.php' );
		include_once( $plugin_maps . 'kc_clients_grid_item.php' );
		include_once( $plugin_maps . 'kc_scene_gradient.php' );
		include_once( $plugin_maps . 'kc_scene_particles_default.php' );
		include_once( $plugin_maps . 'kc_scene_particles_digital.php' );
		include_once( $plugin_maps . 'kc_scene_snow_particles.php' );
		include_once( $plugin_maps . 'kc_scene_confetti_particles.php' );
		include_once( $plugin_maps . 'kc_scene_moving_particles.php' );
		include_once( $plugin_maps . 'kc_scene_gravity_particles.php' );
		include_once( $plugin_maps . 'kc_scene_journey_particles.php' );
		include_once( $plugin_maps . 'kc_scene_lines_particles.php' );
		include_once( $plugin_maps . 'kc_scene_waves_particles.php' );
		include_once( $plugin_maps . 'kc_scene_particles_circles.php' );
		include_once( $plugin_maps . 'kc_list.php' );
		include_once( $plugin_maps . 'kc_hero_slider_slide.php' );
		include_once( $plugin_maps . 'kc_social_icons.php' );
		include_once( $plugin_maps . 'kc_hero_slider.php' );
		include_once( $plugin_maps . 'kc_team_slider.php' );
		include_once( $plugin_maps . 'kc_testimonials_slider.php' );
		include_once( $plugin_maps . 'kc_custom_contact_form.php' );
		include_once( $plugin_maps . 'kc_custom_tabs.php' );
		include_once( $plugin_maps . 'kc_custom_tabs_tab.php' );
		include_once( $plugin_maps . 'kc_custom_accordions.php' );
		include_once( $plugin_maps . 'kc_custom_accordions_accordion.php' );
		include_once( $plugin_maps . 'kc_pricing_table.php' );
		include_once( $plugin_maps . 'kc_blockquote.php' );
		include_once( $plugin_maps . 'kc_recent_posts.php' );

	endif;
}

