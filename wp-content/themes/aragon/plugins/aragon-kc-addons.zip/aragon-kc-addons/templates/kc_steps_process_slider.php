<?php
$el_classes = apply_filters('kc-el-class', $atts);
!empty($extra_class) ? $el_classes[] = $extra_class : null;
$steps_type = $atts['kc_steps_type'];
?>

<?php if ($steps_type == 'steps-slider-type-1'): ?>
    <div class="steps-wrapper">
        <div class="steps-slider-type-1 d-flex flex-wrap <?php echo implode(' ', $el_classes); ?>">
            <div class="swiper-container swiper-steps-slider">
                <!-- Additional required wrapper -->
                <div class="swiper-wrapper">
                    <?php $index = 1; ?>
                    <?php foreach ($atts['kc_steps_process_group'] as $key => $item): ?>
                        <?php
                        $step_title = $item->kc_step_title;
                        $step_body = $item->kc_step_body;
                        $step_icon = $item->kc_step_background_icon; ?>
                        <div class="swiper-slide d-flex align-items-center">
                            <div class="step-wrapper">
                                <div class="step-inner">
                                    <div class="background-icon-wrapper">
                                        <i class="<?php echo $step_icon; ?>"></i>
                                    </div>
                                    <div>
                                        <h2 class="num display-4">
                                            <?php if ($index < 10): ?>
                                                0<?php echo $index; ?>
                                            <?php else: ?>
                                                <?php echo $index; ?>
                                            <?php endif; ?>
                                        </h2>
                                    </div>
                                    <div class="step-body">
                                        <h4 class="title"><?php echo esc_attr($step_title); ?></h4>
                                        <p class="content"><?php echo esc_attr($step_body); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php $index++; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <div class="navigation-wrapper d-flex justify-content-between">
            <div class="arrow-nav swiper-button-prev-steps-slider">
                <i class="fa fa-angle-left"></i>
            </div>
            <div class="arrow-nav swiper-button-next-steps-slider">
                <i class="fa fa-angle-right"></i>
            </div>
        </div>
    </div>
<?php elseif ($steps_type == 'steps-slider-type-2'): ?>
    <div class="steps-wrapper d-flex flex-wrap">
        <?php $index = 1; ?>
        <?php foreach ($atts['kc_steps_process_group'] as $key => $item): ?>
            <?php
            $step_title = $item->kc_step_title;
            $step_body = $item->kc_step_body;
            $step_icon = $item->kc_step_background_icon; ?>
            <div class="<?php echo $steps_type; ?>">
                <div class="step-wrapper">
                    <div class="step-inner">
                        <div class="background-icon-wrapper">
                            <i class="<?php echo $step_icon; ?>"></i>
                        </div>
                        <div>
                            <h2 class="num display-4">
                                <?php if ($index < 10): ?>
                                    0<?php echo $index; ?>
                                <?php else: ?>
                                    <?php echo $index; ?>
                                <?php endif; ?>
                            </h2>
                        </div>
                        <div class="step-body">
                            <h4 class="title"><?php echo esc_attr($step_title); ?></h4>
                            <p class="content"><?php echo esc_attr($step_body); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <?php $index++; ?>
        <?php endforeach; ?>
    </div>
<?php endif; ?>