<?php
$el_classes = apply_filters('kc-el-class', $atts);
!empty($extra_class) ? $el_classes[] = $extra_class : null;
$client_type = $atts['kc_client_type'];
$image_bg_src = $atts['kc_client_bg_image'];
$image_logo_src = $atts['kc_client_image'];
$image_bg = wp_get_attachment_image_src($image_bg_src, 'full');
$image_logo = wp_get_attachment_image_src($image_logo_src, 'full');
$title = $atts['kc_client_title'];
$content = $atts['kc_client_content'];
?>

<?php if ($client_type == 'clients-grid-item-type-1'): ?>
    <div class="<?php echo $client_type; ?>">
        <div class="client-inner d-flex justify-content-center align-items-center"
             style="background-image: url(<?php echo $image_bg[0]; ?>)">
            <div class="content-wrapper z-index-100">
                <div class="img-wrapper">
                    <img src="<?php echo $image_logo[0]; ?>" alt="<?php echo esc_attr__('Client','aragon_kc_addons');
                    ?>">
                </div>
                <p class="content">
                    <?php echo $content; ?>
                </p>
            </div>
        </div>
    </div>
<?php elseif ($client_type == 'clients-grid-item-type-2'): ?>
<?php endif; ?>
