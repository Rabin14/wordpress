<?php
$accordion_type = $atts['kc_accordions_type'];
?>

<div class="accordion js-accordion <?php echo $accordion_type; ?>">
    <?php echo do_shortcode(str_replace('kc_custom_accordions#', 'kc_custom_accordions', $content)); ?>
</div>