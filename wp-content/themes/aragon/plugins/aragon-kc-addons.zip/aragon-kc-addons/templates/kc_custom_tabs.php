<?php
$tabs_type = $atts['kc_tabs_type'];
?>

<div class="tab <?php echo $tabs_type; ?>">
    <ul class="tabs-header"></ul>
    <div class="tab-content">
        <?php echo do_shortcode(str_replace('kc_custom_tabs#', 'kc_custom_tabs', $content)); ?>
    </div>
</div>
