<?php
$el_classes = apply_filters( 'kc-el-class', $atts );
! empty( $extra_class ) ? $el_classes[] = $extra_class : null;
$clients_slider_type = $atts['kc_clients_type'];
?>

<?php if($clients_slider_type == 'clients-slider-type-1'): ?>
<div class="<?php echo $clients_slider_type; ?> <?php echo implode( ' ', $el_classes ); ?>">
	<div class="swiper-container swiper-clients">
		<div class="swiper-wrapper ">
			<?php foreach ( $atts['kc_clients_group'] as $key => $item ): ?>
				<?php
				$client_image     = $item->kc_client_image;
				$image_attributes = wp_get_attachment_image_src( $client_image, array( 250, 100 ) );
				?>
				<div class="swiper-slide">
                    <img src="<?php echo $image_attributes[0]; ?>" alt="<?php __( 'Client', 'aragon_kc_addons' ); ?>">
                </div>
			<?php endforeach; ?>
		</div>
	</div>
</div>
<?php elseif($clients_slider_type == 'clients-slider-type-2'): ?>
    <div class="<?php echo $clients_slider_type; ?> <?php echo implode( ' ', $el_classes ); ?>">
        <div class="swiper-container swiper-clients">
            <div class="swiper-wrapper ">
                <?php foreach ( $atts['kc_clients_group'] as $key => $item ): ?>
                    <?php
                    $client_image     = $item->kc_client_image;
                    $image_attributes = wp_get_attachment_image_src( $client_image, array( 250, 100 ) );
                    ?>
                    <div class="swiper-slide">
                       <div class="slide-inner">
                           <img src="<?php echo $image_attributes[0]; ?>" alt="<?php __( 'Client', 'aragon_kc_addons'
                           ); ?>">
                       </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
<?php endif; ?>
