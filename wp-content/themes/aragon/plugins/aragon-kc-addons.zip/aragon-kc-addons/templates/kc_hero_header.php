<?php
$el_classes = apply_filters('kc-el-class', $atts);
!empty($extra_class) ? $el_classes[] = $extra_class : null;
$social_links_toggle = $atts['kc_social_link_toggle'];
$scroll_down = $atts['kc_scroll_down'];
?>


<?php
$hero_header_height = $atts['kc_hero_height'];
?>
<style>
    :root {
        --hero-header-height: <?php echo $hero_header_height; ?>;
    }
</style>

<header class="hero-header hero-header-kc <?php echo implode(' ', $el_classes); ?>">

    <div class="hero-header-inner">

        <div class="container-fluid inner-content">

            <?php echo do_shortcode(str_replace('kc_hero_header#', 'kc_hero_header', $content)); ?>

            <?php if($scroll_down == 'yes'): ?>
            <div class="arrow-down">
                <p class="arrow-down-title">
                    <?php esc_html_e('scroll down', 'aragon'); ?>
                </p>
                <i class="sl-arrow-down"></i>
            </div>
            <?php endif; ?>
        </div>

        <?php if ($social_links_toggle == 'yes'): ?>
            <div class="social-side">

                <p class="heading">
                    <?php echo esc_html__('Social networks.', 'aragon_kc_addons'); ?>
                </p>

                <div class="social-wrapper">
                    <?php foreach ($atts['kc_social_links_group'] as $key => $item): ?>

                        <?php if (!empty($item->kc_social_link)): ?>
                            <?php
                            $button_icon = $item->kc_social_icon;
                            $link = explode('|', $item->kc_social_link); ?>

                            <?php
                            if (empty($link[0])) :
                                $link[0] = '#';
                            endif;

                            if (empty($link[2])) :
                                $link[2] = '_self';
                            endif;
                            ?>

                            <a class="social-box" href="<?php echo esc_url($link[0]); ?>"
                               target="<?php echo esc_attr($link[2]); ?>">
                                <i class="<?php echo esc_attr($button_icon); ?>"></i>
                            </a>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>

            </div>
        <?php endif; ?>

    </div>

</header>