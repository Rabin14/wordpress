<div class="canvas-scene">
    <canvas class="confetti-particles canvas-inner"></canvas>
</div>