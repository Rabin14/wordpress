<?php
$title_type = $atts['kc_title_type'];
?>
<div class="section-title <?php echo esc_attr( $title_type ); ?>">
	<?php
    $title = $atts['kc_section_title'];
	$subtitle = $atts['kc_section_subtitle'];
	?>
    <h2 class="title display-5">
		<?php echo esc_html( $title ); ?>
    </h2>
    <h2 class="bg-title">
	    <?php echo esc_html( $title ); ?>
    </h2>
    <p class="subtitle"><?php echo esc_html($subtitle);?></p>
</div>