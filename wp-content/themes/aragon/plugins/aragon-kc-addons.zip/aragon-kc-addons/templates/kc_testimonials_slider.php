<?php
$el_classes = apply_filters('kc-el-class', $atts);
!empty($extra_class) ? $el_classes[] = $extra_class : null;
$testimonials_type = $atts['kc_testimonials_type'];
?>

<?php if ($testimonials_type == 'testimonials-slider-type-1'): ?>
    <div class="container-fluid <?php echo $testimonials_type; ?> <?php echo implode(' ', $el_classes); ?>">
        <div class="swiper-container swiper-testimonials">
            <div class="swiper-wrapper">
                <?php foreach ($atts['kc_review_group'] as $key => $item): ?>
                    <?php
                    $image = $item->kc_person_image;
                    $image_attributes = wp_get_attachment_image_src($image, 'full');
                    $name = $item->kc_person_name;
                    $position = $item->kc_person_position;
                    $review = $item->kc_review;
                    $stars = $item->kc_count_star;
                    ?>
                    <div class="swiper-slide">
                       <div class="d-flex info-wrapper align-items-center">
                           <div class="img-wrapper">
                               <img src="<?php echo $image_attributes[0]; ?>" alt="<?php echo esc_attr__('Person','aragon_kc_addons');?>">
                           </div>
                           <div>
                               <h6 class="author"><?php echo esc_attr($name); ?></h6>
                               <p class="position"><?php echo esc_attr($position); ?></p>
                           </div>
                       </div>
                        <div class="testimonial-wrapper">
                            <p class="review">
                                <?php echo esc_attr($review); ?>
                            </p>
                            <div class="stars-wrapper d-flex">
                                <?php for ($i = 0; $i < $stars; $i++): ?>
                                    <div class="star-wrapper">
                                        <i class="fa fa-star"></i>
                                    </div>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="swiper-pagination-testimonials"></div>
        </div>
    </div>
<?php elseif ($testimonials_type == 'testimonials-slider-type-2'): ?>
    <div class="container-fluid <?php echo $testimonials_type; ?> <?php echo implode(' ', $el_classes); ?>">
        <div class="swiper-container swiper-testimonials">
            <div class="swiper-wrapper">
                <?php foreach ($atts['kc_review_group'] as $key => $item): ?>
                    <?php
                    $image = $item->kc_person_image;
                    $image_attributes = wp_get_attachment_image_src($image, 'full');
                    $name = $item->kc_person_name;
                    $position = $item->kc_person_position;
                    $review = $item->kc_review;
                    $stars = $item->kc_count_star;
                    ?>
                    <div class="swiper-slide">
                        <div class="testimonial-wrapper">
                            <div class="d-flex info-wrapper align-items-center">
                                <div class="img-wrapper">
                                    <img src="<?php echo $image_attributes[0]; ?>" alt="<?php echo esc_attr__
                                    ('Person','aragon_kc_addons');?>">
                                </div>
                                <div>
                                    <h6 class="author"><?php echo esc_attr($name); ?></h6>
                                    <p class="position"><?php echo esc_attr($position); ?></p>
                                    <div class="stars-wrapper d-flex">
                                        <?php for ($i = 0; $i < $stars; $i++): ?>
                                            <div class="star-wrapper">
                                                <i class="fa fa-star"></i>
                                            </div>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                            </div>
                            <p class="review">
                                <?php echo esc_attr($review); ?>
                            </p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="swiper-pagination-testimonials"></div>
        </div>
    </div>
<?php endif; ?>
