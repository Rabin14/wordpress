<?php
$el_classes = apply_filters('kc-el-class', $atts);
!empty($extra_class) ? $el_classes[] = $extra_class : null;
$alignment = $atts['kc_button_alignment'];
?>
<div class="buttons-wrapper d-flex <?php echo $alignment; ?>">
    <?php foreach ($atts['kc_buttons_group'] as $key => $item): ?>

        <?php $button_class = $item->kc_button_type;
        $button_icon_toggle = $item->kc_button_icon_toggle;
        $button_icon = $item->kc_button_icon;
        $button_alignment = $item->kc_button_icon_alignment;
        $link = explode('|', $item->kc_button_link);
        ?>

        <?php
        if (empty($link[0])) :
            $link[0] = '#';
        endif;

        if (empty($link[1])) :
            $link[1] = 'Button';
        endif;

        if (empty($link[2])) :
            $link[2] = '_self';
        endif;
        ?>


        <div class="btn-wrap d-flex">
            <a href="<?php echo esc_url($link[0]); ?>" target="<?php echo $link[2]; ?>"
               class="<?php echo $button_class; ?> <?php echo implode(' ', $el_classes); ?>">
                <?php if ($button_icon_toggle == 'yes'): ?>
                    <?php if ($button_alignment == 'left-icon'): ?>
                        <i class="<?php echo $button_icon; ?> <?php echo $button_alignment; ?>"></i>
                    <?php endif; ?>
                <?php endif; ?>

                <?php echo esc_attr($link[1]); ?>

                <?php if ($button_icon_toggle == 'yes'): ?>
                    <?php if ($button_alignment == 'right-icon'): ?>
                        <i class="<?php echo $button_icon; ?> <?php echo $button_alignment; ?>"></i>
                    <?php endif; ?>
                <?php endif; ?>
            </a>
        </div>


    <?php endforeach; ?>
</div>
