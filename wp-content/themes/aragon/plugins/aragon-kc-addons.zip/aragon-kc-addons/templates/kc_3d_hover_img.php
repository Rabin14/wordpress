<div class="hover-3d-img">
    <div class="hover3d-wrapper">
		<?php
		$img_src = $atts['kc_3d_hover_img'];
		$img     = wp_get_attachment_image_src( $img_src, 'full' );
		?>
        <div class="hover3d-child img-wrapper">
            <img src="<?php echo esc_url( $img[0] ); ?>" class="img-fluid" alt="<?php echo esc_attr__('3d Hover image','aragon_kc_addons');?>">
        </div>
    </div>
</div>