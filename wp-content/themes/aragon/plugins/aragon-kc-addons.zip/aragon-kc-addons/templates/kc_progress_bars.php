<?php
$el_classes = apply_filters('kc-el-class', $atts);
!empty($extra_class) ? $el_classes[] = $extra_class : null;
$index = 1;
$progress_bar_type = $atts['kc_progress_bar_type'];
?>
<?php if ($progress_bar_type == 'progress-bar-type-1'): ?>
    <div class="progress-bars-wrapper <?php echo $progress_bar_type; ?> <?php echo implode(' ', $el_classes); ?>">
        <?php foreach ($atts['kc_progress_bars_group'] as $key => $item): ?>
            <?php
            $title = $item->kc_progress_bar_title;
            $value = $item->kc_progress_bar_value;
            $value = $value / 100;
            ?>
            <div class="<?php echo 'progress-bar-line' . $index; ?> progress-bar-line"
                 data-progress='<?php echo $value; ?>'>
                <p class="progress-bar-title"><?php echo esc_attr($title); ?></p>
            </div>
            <?php $index++; ?>
        <?php endforeach; ?>
    </div>
<?php elseif ($progress_bar_type == 'progress-bar-type-2'): ?>
    <div class="progress-bars-wrapper <?php echo $progress_bar_type; ?> <?php echo implode(' ', $el_classes); ?>">
        <?php foreach ($atts['kc_progress_bars_group'] as $key => $item): ?>
            <?php
            $title = $item->kc_progress_bar_title;
            $value = $item->kc_progress_bar_value;
            $value = $value / 100;
            ?>
            <div class="<?php echo 'progress-bar-line' . $index; ?> progress-bar-line"
                 data-progress='<?php echo $value; ?>'>
                <p class="progress-bar-title"><?php echo esc_attr($title); ?></p>
            </div>
            <?php $index++; ?>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
