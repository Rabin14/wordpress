<div class="canvas-scene">
    <div class="lines-particles">
    </div>
</div>