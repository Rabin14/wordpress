<?php
$el_classes = apply_filters('kc-el-class', $atts);
!empty($extra_class) ? $el_classes[] = $extra_class : null;
$video_url = $atts['kc_video_url'];
$video_toggle_type = $atts['kc_video_box_type'];
?>
<?php if ($video_toggle_type == 'video-toggle-type-1'): ?>
    <div class="<?php echo $video_toggle_type; ?>">
        <a class="popup-modal video-popup d-flex align-items-center justify-content-center"
           href="#<?php echo $el_classes[1]; ?>">
            <div class="play-btn">
                <i class="fa fa-play"></i>
            </div>
        </a>
    </div>
<?php elseif ($video_toggle_type == 'video-toggle-type-2'): ?>
    <div class="<?php echo $video_toggle_type; ?>">
        <a class="popup-modal video-popup d-flex align-items-center justify-content-center"
           href="#<?php echo $el_classes[1]; ?>">
            <div class="play-btn">
                <i class="fa fa-play"></i>
            </div>
        </a>
    </div>
<?php elseif ($video_toggle_type == 'video-toggle-type-3'): ?>
    <div class="<?php echo $video_toggle_type; ?>">
        <a class="popup-modal video-popup d-flex align-items-center justify-content-center"
           href="#<?php echo $el_classes[1]; ?>">
            <div class="play-btn">
                <i class="sl-control-play"></i>
            </div>
        </a>
    </div>
<?php endif; ?>
<div id="<?php echo $el_classes[1]; ?>" class="white-popup-block mfp-hide mfp-fade">
    <div class="modal-video-box">
        <iframe src="<?php echo esc_url($video_url); ?>"
                allowfullscreen></iframe>
        <button type="button" class="mfp-close">×</button>
    </div>
</div>