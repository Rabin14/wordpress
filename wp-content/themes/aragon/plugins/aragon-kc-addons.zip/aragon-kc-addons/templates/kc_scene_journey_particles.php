<div class="canvas-scene">
    <canvas class="journey-particles canvas-inner"></canvas>
</div>