<?php
$el_classes = apply_filters('kc-el-class', $atts);
!empty($extra_class) ? $el_classes[] = $extra_class : null;
$quote_type = $atts['kc_quote_type'];
$quote_text = $atts['kc_quote_text'];
?>

<?php if ($quote_type == 'blockquote-type-1'): ?>
    <blockquote class="<?php echo $quote_type ?>">
        <div class="icon-wrapper">
            <i class="fa fa-quote-right"></i>
        </div>
        <?php echo esc_html($quote_text); ?>
    </blockquote>
<?php elseif ($quote_type == 'blockquote-type-2'): ?>
    <blockquote class="<?php echo $quote_type ?>">
        <div class="icon-wrapper">
            <i class="fa fa-quote-right"></i>
        </div>
        <?php echo esc_html($quote_text); ?>
    </blockquote>
<?php elseif ($quote_type == 'blockquote-type-3'): ?>
    <blockquote class="<?php echo $quote_type ?>">
        <?php echo esc_html($quote_text); ?>
    </blockquote>
<?php endif; ?>