<div class="canvas-scene">
    <canvas class="snow-particles canvas-inner"></canvas>
</div>
