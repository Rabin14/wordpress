<?php
$el_classes = apply_filters('kc-el-class', $atts);
!empty($extra_class) ? $el_classes[] = $extra_class : null;
$alignment = $atts['kc_networks_alignment'];
$type = $atts['kc_network_type'];
?>

<?php if ($type == 'social-icons-type-1'): ?>
    <div class="d-flex <?php echo $alignment; ?>">
        <div class="<?php echo $type; ?> d-flex flex-wrap justify-content-center">
            <?php foreach ($atts['kc_networks_group'] as $key => $item): ?>
                <?php
                $link = $item->kc_network_link;
                $icon = $item->kc_network_icon;
                $background = $item->kc_network_background;
                $color = $item->kc_network_icon_color;
                ?>
                <a class="social-box <?php echo implode(' ', $el_classes); ?>" href="<?php echo esc_url($link); ?>"
                   style="background-color: <?php echo $background; ?>">
                    <i class="<?php echo $icon; ?>" style="color: <?php echo $color; ?>"></i>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
<?php elseif ($type == 'social-icons-type-2'): ?>
    <div class="d-flex <?php echo $alignment; ?>">
        <div class="<?php echo $type; ?> d-flex flex-wrap justify-content-center">
            <?php foreach ($atts['kc_networks_group'] as $key => $item): ?>
                <?php
                $link = $item->kc_network_link;
                $icon = $item->kc_network_icon;
                $background = $item->kc_network_background;
                $color = $item->kc_network_icon_color;
                ?>
                <a class="social-box <?php echo implode(' ', $el_classes); ?>" href="<?php echo esc_url($link); ?>"
                   style="background-color: <?php echo $background; ?>">
                    <i class="<?php echo $icon; ?>" style="color: <?php echo $color; ?>"></i>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
<?php elseif ($type == 'social-icons-type-3'): ?>
    <div class="d-flex <?php echo $alignment; ?>">
        <div class="<?php echo $type; ?> d-flex flex-wrap justify-content-center">
            <?php foreach ($atts['kc_networks_group'] as $key => $item): ?>
                <?php
                $link = $item->kc_network_link;
                $icon = $item->kc_network_icon;
                $background = $item->kc_network_background;
                $color = $item->kc_network_icon_color;
                ?>
                <a class="social-box <?php echo implode(' ', $el_classes); ?>" href="<?php echo esc_url($link); ?>"
                   style="background-color: <?php echo $background; ?>; border: 2px solid <?php echo $background; ?>;">
                    <i class="<?php echo $icon; ?>" style="color: <?php echo $color; ?>"></i>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>