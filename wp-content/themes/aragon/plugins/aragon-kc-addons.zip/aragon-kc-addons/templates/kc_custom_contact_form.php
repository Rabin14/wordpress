<?php
$el_classes = apply_filters( 'kc-el-class', $atts );
! empty( $extra_class ) ? $el_classes[] = $extra_class : null;
ob_start();

?>

<div class="<?php echo implode( ' ', $el_classes ); ?> kc_contact_form7">
    <?php
    global $wpdb;
    $form = $wpdb->get_results( "SELECT `ID` FROM `" . $wpdb->posts . "` WHERE `post_type` = 'wpcf7_contact_form' AND `post_name` = '" . esc_attr( sanitize_title( $atts['form'] ) ) . "' LIMIT 1" );
    if ( ! empty( $form ) ) {
        echo do_shortcode( '[contact-form-7 id="' . $form[0]->ID . '" title="' . esc_attr( $atts['form'] ) . '"]' );
    } else {
        echo __( 'Please select one of contact form 7 for display.', 'aragon_kc_addons' );
    }
    ?>
</div>