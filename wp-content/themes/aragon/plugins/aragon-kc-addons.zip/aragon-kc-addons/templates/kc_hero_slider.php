<?php $el_classes = apply_filters('kc-el-class', $atts);
!empty($extra_class) ? $el_classes[] = $extra_class : null;
$hero_slider_height = $atts['kc_hero_height'];
$scroll_down = $atts['kc_scroll_down'];
?>
<style>
    :root {
        --hero-slider-height: <?php echo $hero_slider_height;
		?>;
    }
</style>
<header class='hero-slider hero-header-kc'>
    <div class="swiper-container swiper-hero <?php echo implode(' ', $el_classes); ?>">
        <div class="swiper-wrapper">
            <?php echo do_shortcode(str_replace('kc_hero_slider#', 'kc_hero_slider', $content)); ?>
        </div>
        <div class="d-flex justify-content-between navigation">
            <div class="swiper-button-prev-hero button-nav">
                <i class="fa fa-chevron-left"></i>
            </div>
            <div class="swiper-button-next-hero button-nav">
                <i class="fa fa-chevron-right"></i>
            </div>
        </div>
        <div class="swiper-scrollbar-hero"></div>
        <?php if($scroll_down == 'yes'): ?>
        <div class="arrow-down">
            <p class="arrow-down-title">
                <?php esc_html_e('scroll down', 'aragon'); ?>
            </p>
            <i class="sl-arrow-down"></i>
        </div>
        <?php endif; ?>
    </div>
</header>