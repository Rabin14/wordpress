<?php
$el_classes = apply_filters('kc-el-class', $atts);
!empty($extra_class) ? $el_classes[] = $extra_class : null;
$list_type = $atts['kc_list_type'];
?>
<?php if ($list_type == 'list-type-1'): ?>
    <div class="<?php echo implode(' ', $el_classes); ?>">
        <ul class="list <?php echo $list_type; ?>">
            <?php foreach ($atts['kc_lists_group'] as $key => $item): ?>
                <?php $list_item = $item->kc_list_title; ?>
                <li><h6 class="li-item"><?php echo esc_attr($list_item); ?></h6></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php elseif ($list_type == 'list-type-2'): ?>
    <div class="<?php echo implode(' ', $el_classes); ?>">
        <ul class="list <?php echo $list_type; ?>">
            <?php foreach ($atts['kc_lists_group'] as $key => $item): ?>
                <?php $list_item = $item->kc_list_title; ?>
                <li><p class="li-item"><?php echo esc_attr($list_item); ?></p></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php elseif ($list_type == 'list-type-3'): ?>
    <div class="<?php echo implode(' ', $el_classes); ?>">
        <ul class="list <?php echo $list_type; ?>">
            <?php foreach ($atts['kc_lists_group'] as $key => $item): ?>
                <?php $list_item = $item->kc_list_title; ?>
                <li><p class="li-item"><?php echo esc_attr($list_item); ?></p></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>