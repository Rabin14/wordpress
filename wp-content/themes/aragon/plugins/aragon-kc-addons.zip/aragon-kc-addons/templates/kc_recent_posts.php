<?php
$count = $atts['kc_post_count'];
$sticky = get_option('sticky_posts');
$type = $atts['kc_recent_posts_type'];
$args = array(
    'posts_per_page' => $count,
    'orderby' => 'post_date',
    'ignore_sticky_posts' => 1,
    'post__not_in' => $sticky,
    'tax_query' => array(
        'relation' => 'AND',
        array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-quote'),
            'operator' => 'NOT IN',
        ),
        array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-aside'),
            'operator' => 'NOT IN',
        ),
        array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-link'),
            'operator' => 'NOT IN',
        ),
        array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-audio'),
            'operator' => 'NOT IN',
        ),
        array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-gallery'),
            'operator' => 'NOT IN',
        ),
        array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-video'),
            'operator' => 'NOT IN',
        )
    )
) ?>
<?php $query = new WP_Query($args); ?>
<?php if ($type == 'recent-posts-type-1'): ?>
    <div class="<?php echo $type ?>">
        <div class="row">
            <?php while ($query->have_posts()) : ?>
                <?php $query->the_post(); ?>
                <?php
                $title = get_the_title();
                $excerpt = get_the_excerpt();
                ?>
                <div class="recent-post-card col-lg-4">
                    <div class="post-inner">
                        <div class="post-header">
                            <div class="post-tag">
                                <?php
                                $posttags = get_the_tags();
                                $count = 0;
                                if ($posttags) {
                                    foreach ($posttags as $tag) {
                                        $count++;
                                        if (1 == $count) {
                                            ?>
                                            <a href="<?php echo get_tag_link($tag); ?>" class="tag">
                                                <i class="fa fa-tag icon-tag"></i><?php echo esc_attr($tag->name) . ' '; ?>
                                            </a>
                                            <?php
                                        }
                                    }
                                }
                                ?>
                            </div>
                            <a href="<?php the_permalink(); ?>">
                                <img src="<?php the_post_thumbnail_url(); ?>" class="img-fluid" alt="<?php the_title();?>">
                            </a>
                        </div>
                        <div class="post-body">
                            <div class="info-wrapper">
                                <div class="info-part">
                                    <i class="fa fa-clock info-icon"></i>
                                    <div class="date">
                                        <?php echo get_the_date(); ?>
                                    </div>
                                </div>
                                <div class="delimiter">|</div>
                                <div class="info-part">
                                    <i class="fa fa-user info-icon"></i>
                                    <?php the_author_posts_link(); ?>
                                </div>
                            </div>
                            <h5 class="post-title">
                                <a href="<?php the_permalink(); ?>">
                                    <?php echo wp_trim_words($title, 10, '...'); ?>
                                </a>
                            </h5>
                            <div>
                                <?php echo wp_trim_words($excerpt, 25, '...'); ?>
                            </div>
                            <div class="button-wrapper d-flex">
                                <a href="<?php the_permalink(); ?>" class="recent-post-btn">
                                    <?php echo esc_html__('Read More', 'aragon'); ?>
                                    <i class="sl sl-arrow-right-circle"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
<?php elseif ($type == 'recent-posts-type-2'): ?>
    <div class="<?php echo $type ?>">
        <div class="row">
            <?php while ($query->have_posts()) : ?>
                <?php $query->the_post(); ?>
                <?php
                $title = get_the_title();
                $excerpt = get_the_excerpt();
                ?>
                <div class="recent-post-card col-lg-4">
                    <div class="post-inner" style="background-image: url(<?php the_post_thumbnail_url(); ?>)">
                        <div class="post-tag">
                            <?php
                            $posttags = get_the_tags();
                            $count = 0;
                            if ($posttags) {
                                foreach ($posttags as $tag) {
                                    $count++;
                                    if (1 == $count) {
                                        ?>
                                        <a href="<?php echo get_tag_link($tag); ?>" class="tag">
                                            <i class="fa fa-tag icon-tag"></i><?php echo esc_attr($tag->name) . ' '; ?>
                                        </a>
                                        <?php
                                    }
                                }
                            }
                            ?>
                        </div>
                        <div class="post-body d-flex align-items-end">
                            <div class="content-wrapper">
                                <div class="show-part">
                                    <div class="info-wrapper">
                                        <div class="info-part">
                                            <i class="fa fa-clock info-icon"></i>
                                            <div class="date">
                                                <?php echo get_the_date(); ?>
                                            </div>
                                        </div>
                                        <div class="delimiter">|</div>
                                        <div class="info-part">
                                            <i class="fa fa-user info-icon"></i>
                                            <?php the_author_posts_link(); ?>
                                        </div>
                                    </div>
                                    <h6 class="post-title">
                                        <a href="<?php the_permalink(); ?>">
                                            <?php echo wp_trim_words($title, 10, '...'); ?>
                                        </a>
                                    </h6>
                                </div>
                                <div class="hide-part">
                                    <div class="content">
                                        <?php echo wp_trim_words($excerpt, 25, '...'); ?>
                                    </div>
                                    <div class="button-wrapper d-flex">
                                        <a href="<?php the_permalink(); ?>" class="recent-post-btn">
                                            <?php echo esc_html__('Read More', 'aragon'); ?>
                                            <i class="sl sl-arrow-right-circle"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
<?php elseif ($type == 'recent-posts-type-3'): ?>
    <div class="<?php echo $type ?>">
        <?php while ($query->have_posts()) : ?>
            <?php $query->the_post(); ?>
            <?php
            $title = get_the_title();
            $excerpt = get_the_excerpt();
            ?>
            <div class="recent-post-card-wrapper">
                <div class="recent-post-card">
                    <div class="post-inner" style="background-image: url(<?php the_post_thumbnail_url(); ?>)">
                        <div class="post-tag">
                            <?php
                            $posttags = get_the_tags();
                            $count = 0;
                            if ($posttags) {
                                foreach ($posttags as $tag) {
                                    $count++;
                                    if (1 == $count) {
                                        ?>
                                        <a href="<?php echo get_tag_link($tag); ?>" class="tag">
                                            <i class="fa fa-tag icon-tag"></i><?php echo esc_attr($tag->name) . ' '; ?>
                                        </a>
                                        <?php
                                    }
                                }
                            }
                            ?>
                        </div>
                        <a class="author-wrapper"
                           href="<?php echo get_author_posts_url(get_the_author_meta('user_email'), get_the_author_meta('user_nicename')); ?>">
                            <?php echo get_avatar(get_the_author_meta('user_email'), 64); ?>
                        </a>
                        <div class="post-body">
                            <div class="info-wrapper">
                                <div class="info-part">
                                    <i class="fa fa-clock info-icon"></i>
                                    <div class="date">
                                        <?php echo get_the_date(); ?>
                                    </div>
                                </div>
                            </div>
                            <h5 class="post-title">
                                <a href="<?php the_permalink(); ?>">
                                    <?php echo wp_trim_words($title, 10, '...'); ?>
                                </a>
                            </h5>
                            <div class="content">
                                <?php echo wp_trim_words($excerpt, 25, '...'); ?>
                            </div>
                            <div class="button-wrapper d-flex">
                                <a href="<?php the_permalink(); ?>" class="recent-post-btn">
                                    <?php echo esc_html__('Read More', 'aragon'); ?>
                                    <i class="sl sl-arrow-right-circle"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
<?php endif; ?>
<?php wp_reset_postdata(); ?>
