<?php
$el_classes = apply_filters('kc-el-class', $atts);
!empty($extra_class) ? $el_classes[] = $extra_class : null;
$member_type = $atts['kc_member_type'];
$member_image = $atts['kc_member_image'];
$member_name = $atts['kc_member_name'];
$member_position = $atts['kc_member_position'];
$social_trigger = $atts['kc_social_toggle'];
$image_attributes = wp_get_attachment_image_src($member_image, 'full');
?>
<?php if ($member_type == 'team-member-type-1'): ?>
    <div class="<?php echo $member_type; ?> <?php echo implode(' ',
        $el_classes); ?>">
        <div class="img-wrapper d-flex justify-content-center align-items-center">
            <img src="<?php echo $image_attributes[0]; ?>" class="img-fluid"
                 alt="<?php __('Member', 'aragon_kc_addons'); ?>">
            <div class="content d-flex flex-column align-items-center justify-content-center">
                <div>
                    <h6 class="position"><?php echo esc_attr($member_position); ?></h6>
                    <h4 class="name"><?php echo esc_attr($member_name); ?></h4>
                </div>
                <?php if ($social_trigger == "yes"): ?>
                    <div class="social-wrapper d-flex">
                        <?php foreach ($atts['kc_member_social_group'] as $key => $item): ?>
                            <?php
                            if (isset ($item->kc_social_icon) && isset ($item->kc_team_link)) :
                                $social_icon = $item->kc_social_icon;
                                $social_link = $item->kc_team_link;
                                $social_color = $item->kc_social_color;
                            endif;
                            if (!empty($social_link)):?>
                                <a class="social-box" href="<?php echo esc_url($social_link); ?>"
                                   style="background-color: <?php echo $social_color; ?>; border: 2px solid <?php echo $social_color; ?>">
                                    <?php if (!empty($social_icon)): ?>
                                        <i class="<?php echo $social_icon; ?>"></i>
                                    <?php endif; ?>
                                </a>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php elseif ($member_type == 'team-member-type-2'): ?>
    <div class="hover3d-wrapper">
        <div class="hover3d-child">
            <div class="d-flex justify-content-center  align-items-center <?php echo $member_type; ?> <?php echo implode(' ',
                $el_classes); ?>">
                <div class="img-wrapper">
                    <img src="<?php echo $image_attributes[0]; ?>" class="img-fluid"
                         alt="<?php __('Member', 'kc_kc_addons'); ?>">
                </div>
                <div class="description-box">
                    <h4 class="name"><?php echo esc_attr($member_name); ?></h4>
                    <p class="position"><?php echo esc_attr($member_position); ?></p>
                    <?php if ($social_trigger == "yes"): ?>
                        <div class="social-wrapper d-flex">
                            <?php foreach ($atts['kc_member_social_group'] as $key => $item): ?>
                                <?php
                                if (isset ($item->kc_social_icon) && isset ($item->kc_team_link)) :
                                    $social_icon = $item->kc_social_icon;
                                    $social_link = $item->kc_team_link;
                                endif;
                                if (!empty($social_link)):?>
                                    <a class="social-box" href="<?php echo esc_url($social_link); ?>">
                                        <?php if (!empty($social_icon)): ?>
                                            <i class="<?php echo $social_icon; ?>"></i>
                                        <?php endif; ?>
                                    </a>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php elseif ($member_type == 'team-member-type-3'): ?>
    <div class="<?php echo $member_type; ?> <?php echo implode(' ',
        $el_classes); ?>">
        <div class="img-wrapper">
            <img src="<?php echo $image_attributes[0]; ?>" class="img-fluid"
                 alt="<?php __('Member', 'kc_kc_addons'); ?>">
        </div>
        <div class="description-box">
            <div class="content-wrapper">
                <p class="position"><?php echo esc_attr($member_position); ?></p>
                <h4 class="name"><?php echo esc_attr($member_name); ?></h4>
                <?php if ($social_trigger == "yes"): ?>
                    <div class="social-wrapper d-flex">
                        <?php foreach ($atts['kc_member_social_group'] as $key => $item): ?>
                            <?php
                            if (isset ($item->kc_social_icon) && isset ($item->kc_team_link)) :
                                $social_icon = $item->kc_social_icon;
                                $social_link = $item->kc_team_link;
                                $social_color = $item->kc_social_color;
                            endif;
                            if (!empty($social_link)):?>
                                <a class="social-box" href="<?php echo esc_url($social_link); ?>"
                                   style="background-color: <?php echo $social_color; ?>; border: 2px solid <?php echo $social_color; ?>">
                                    <?php if (!empty($social_icon)): ?>
                                        <i class="<?php echo $social_icon; ?>"></i>
                                    <?php endif; ?>
                                </a>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php endif; ?>

