<?php
$el_classes = apply_filters('kc-el-class', $atts);
!empty($extra_class) ? $el_classes[] = $extra_class : null;
$pricing_type = $atts['kc_pricing_table_type'];
$main_plan_trigger = $atts['kc_main_table_toggle'];
$button_trigger = $atts['kc_plan_button'];
$pricing_plan = $atts['kc_pricing_plan'];
$symbol = $atts['kc_pricing_symbol'];
$cost = $atts['kc_plan_cost'];
$link = explode('|', $atts['kc_button_link']);
if (empty($link[0])) {
    $link[0] = '#';
}
if (empty($link[1])) {
    $link[1] = 'Button';
}
if (empty($link[2])) {
    $link[2] = '_self';
}
?>
<?php if ($pricing_type == 'pricing-table-type-1'): ?>
    <div class="<?php echo $pricing_type; ?> <?php echo implode(' ', $el_classes); ?>">
        <div class="pricing-table-inner <?php if ($main_plan_trigger == 'yes'): ?>main-plan<?php endif; ?>">
            <div class="pricing-table-header">
            </div>
            <div class="pricing-table">
                <div class="pricing-header">
                    <p class="pricing-type"><?php echo esc_attr($pricing_plan); ?></p>
                    <h2 class="price"><span><?php echo $symbol; ?></span><?php echo esc_attr($cost); ?></h2>
                </div>
                <ul class="features-list">
                    <?php foreach ($atts['kc_features_group'] as $key => $item): ?>
                        <?php
                        $feature_title = $item->kc_feature_title;
                        ?>
                        <li><p><?php echo esc_attr($feature_title); ?></p></li>
                    <?php endforeach; ?>
                </ul>
                <?php if ($button_trigger == 'yes'): ?>
                    <div class="buttons-wrapper d-flex">
                        <a target="<?php echo $link[2]; ?>"
                           href="<?php echo esc_url($link[0]); ?>"><?php echo esc_attr($link[1]); ?></a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php endif; ?>
