<?php
$tab_title = $atts['kc_tab_title'];
?>

<div class="tabs-item" data-tab-title="<?php echo esc_attr($tab_title); ?>">
    <?php echo do_shortcode(str_replace('kc_custom_tabs_tab#', 'kc_custom_tabs_tab', $content)); ?>
</div>
