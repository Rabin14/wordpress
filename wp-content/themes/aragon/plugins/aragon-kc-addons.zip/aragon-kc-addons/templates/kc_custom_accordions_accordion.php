<?php
$title = $atts['kc_accordion_title'];
$active = $atts['kc_accordion_active'];
?>
<div class="accordion-item js-accordion-item <?php if ($active == 'yes'): echo 'active'; endif; ?>">
    <div class="accordion-header js-accordion-header">
        <h6 class="title"><?php echo $title; ?></h6>
    </div>
    <div class="accordion-body js-accordion-body">
        <div class="accordion-body-contents">
            <?php echo do_shortcode(str_replace('kc_custom_accordions_accordion#', 'kc_custom_accordions_accordion', $content)); ?>
        </div>
    </div>
</div>
