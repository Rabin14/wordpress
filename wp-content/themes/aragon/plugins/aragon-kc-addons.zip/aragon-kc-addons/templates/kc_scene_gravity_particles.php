<div class="canvas-scene">
    <canvas class="gravity-particles canvas-inner"></canvas>
</div>