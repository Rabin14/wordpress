<div class="canvas-scene">
	<div class="gradient-background canvas-inner"></div>
</div>
