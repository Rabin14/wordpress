<?php
$el_classes = apply_filters('kc-el-class', $atts);
!empty($extra_class) ? $el_classes[] = $extra_class : null;
$counters_type = $atts['kc_counters_type'];
$index = 1;
?>
<?php if ($counters_type == 'counters-type-1'): ?>
    <div class="<?php echo implode(' ', $el_classes); ?> <?php echo esc_attr($counters_type); ?>">
        <div class="row counters-wrapper justify-content-center">
            <?php foreach ($atts['kc_counters'] as $key => $item): ?>
                <?php
                $counter_title = $item->kc_counter_title;
                $count = $item->kc_counter_count;
                $icon_toggle = $item->kc_counter_icon_toggle;
                $icon = $item->kc_counter_icon;
                ?>
                <div class="col-6 col-lg-3 counter-box d-flex flex-column align-items-center">
                    <span class="prop-obj <?php echo 'prop-obj' . $index; ?>"
                          data-count="<?php echo $count; ?>">0</span>
                    <p class="title-counter"><?php echo esc_attr($counter_title); ?></p>
                    <?php if ($icon_toggle == 'yes'): ?>
                        <div class="counter-icon">
                            <i class="<?php echo $icon; ?>"></i>
                        </div>
                    <?php endif; ?>
                </div>
                <?php $index++; ?>
            <?php endforeach; ?>
        </div>
    </div>
<?php elseif ($counters_type == 'counters-type-2'): ?>
    <div class="<?php echo implode(' ', $el_classes); ?> <?php echo esc_attr($counters_type); ?>">
        <div class="row counters-wrapper justify-content-center">
            <?php foreach ($atts['kc_counters'] as $key => $item): ?>
                <?php
                $counter_title = $item->kc_counter_title;
                $count = $item->kc_counter_count;
                $icon_toggle = $item->kc_counter_icon_toggle;
                $icon = $item->kc_counter_icon;
                $img_src = $item->kc_counter_bg;
                $img = wp_get_attachment_image_src($img_src, 'full');
                ?>
                <div class="col-sm-4 counter-box d-flex flex-column align-items-center  <?php if (!empty($img_src)): echo 'counter-bg-overlay'; endif; ?>"
                style="background-image: url(<?php echo $img[0]; ?>)">
                    <span class="prop-obj <?php echo 'prop-obj' . $index; ?>"
                          data-count="<?php echo $count; ?>">0</span>
                    <p class="title-counter"><?php echo esc_attr($counter_title); ?></p>
                    <?php if ($icon_toggle == 'yes'): ?>
                        <div class="counter-icon">
                            <i class="<?php echo $icon; ?>"></i>
                        </div>
                    <?php endif; ?>
                </div>
                <?php $index++; ?>
            <?php endforeach; ?>
        </div>
    </div>
<?php elseif ($counters_type == 'counters-type-3'): ?>
    <div class="<?php echo implode(' ', $el_classes); ?> <?php echo esc_attr($counters_type); ?>">
        <div class="row counters-wrapper justify-content-center">
            <?php foreach ($atts['kc_counters'] as $key => $item): ?>
                <?php
                $counter_title = $item->kc_counter_title;
                $count = $item->kc_counter_count;
                $icon_toggle = $item->kc_counter_icon_toggle;
                $icon = $item->kc_counter_icon;
                ?>
                <div class="col-6 col-sm-4 counter-box d-flex flex-column align-items-center">
                    <p class="title-counter"><?php echo esc_attr($counter_title); ?></p>
                    <span class="prop-obj <?php echo 'prop-obj' . $index; ?>"
                          data-count="<?php echo $count; ?>">0</span>
                    <?php if ($icon_toggle == 'yes'): ?>
                        <div class="counter-icon">
                            <i class="<?php echo $icon; ?>"></i>
                        </div>
                    <?php endif; ?>
                </div>
                <?php $index++; ?>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>