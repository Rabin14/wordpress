<?php
$el_classes = apply_filters('kc-el-class', $atts);
!empty($extra_class) ? $el_classes[] = $extra_class : null;
$service_class = $atts['kc_service_type'];
$icon = $atts['kc_service_icon'];
$title = $atts['kc_service_title'];
$text = $atts['kc_service_text'];
$index = $atts['kc_service_index'];
?>

<?php if ($service_class == 'service-type-1'): ?>
    <div class="<?php echo implode(' ', $el_classes); ?> <?php echo $service_class; ?>">
        <i class="<?php echo esc_attr($icon); ?> icon"></i>
        <h5 class="title">
            <?php echo esc_html($title); ?>
        </h5>
        <p class="content">
            <?php echo esc_html($text); ?>
        </p>
    </div>
<?php elseif ($service_class == 'service-type-2'): ?>
    <div class="d-flex <?php echo implode(' ', $el_classes); ?> <?php echo $service_class; ?>">
        <div class="icon-wrapper">
            <i class="<?php echo esc_attr($icon); ?> icon"></i>
        </div>
        <div class="content-wrapper">
            <h5 class="title">
                <?php echo esc_html($title); ?>
            </h5>
            <p class="content">
                <?php echo esc_html($text); ?>
            </p>
        </div>
    </div>
<?php elseif ($service_class == 'service-type-3'): ?>
    <div class="d-flex <?php echo implode(' ', $el_classes); ?> <?php echo $service_class; ?>">
        <div class="icon-wrapper">
            <i class="<?php echo esc_attr($icon); ?> icon"></i>
        </div>
        <div class="content-wrapper">
            <h6 class="title">
                <?php echo esc_html($title); ?>
            </h6>
            <p class="content">
                <?php echo esc_html($text); ?>
            </p>
        </div>
    </div>
<?php elseif ($service_class == 'service-type-4'): ?>
    <div class="d-flex flex-column <?php echo implode(' ', $el_classes); ?> <?php echo $service_class; ?>">
        <div class="icon-wrapper">
            <i class="<?php echo esc_attr($icon); ?> icon"></i>
        </div>
        <div class="content-wrapper">
            <h5 class="title">
                <?php echo esc_html($title); ?>
            </h5>
            <p class="content">
                <?php echo esc_html($text); ?>
            </p>
        </div>
    </div>
<?php elseif ($service_class == 'service-type-5'): ?>
    <div class="d-flex <?php echo implode(' ', $el_classes); ?> <?php echo $service_class; ?>">
        <div class="number-wrapper">
            <p class="number">
                <?php if ($index < 10): echo '0' . $index; else: echo $index; endif; ?>
            </p>
        </div>
        <div class="content-wrapper">
            <h5 class="title">
                <?php echo esc_html($title); ?>
            </h5>
            <p class="content">
                <?php echo esc_html($text); ?>
            </p>
        </div>
        <?php $index++; ?>
    </div>
<?php endif; ?>