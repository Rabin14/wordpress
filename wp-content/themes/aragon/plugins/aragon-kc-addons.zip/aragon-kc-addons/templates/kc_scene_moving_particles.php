<div class="canvas-scene">
	<canvas class="moving-particles canvas-inner"></canvas>
</div>
