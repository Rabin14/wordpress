<?php
$el_classes = apply_filters('kc-el-class', $atts);
!empty($extra_class) ? $el_classes[] = $extra_class : null;
$team_slider_type = $atts['kc_team_slider_type'];
?>

<?php if ($team_slider_type == 'team-slider-type-1'): ?>
    <section class="<?php echo $team_slider_type; ?> <?php echo implode(' ', $el_classes); ?>">
        <div class="swiper-container swiper-team">
            <div class="swiper-wrapper">
                <?php foreach ($atts['kc_members_group'] as $key => $item): ?>
                    <?php
                    $member_image = $item->kc_member_image;
                    $member_name = $item->kc_member_name;
                    $member_position = $item->kc_member_position;
                    $member_social_toggle = $item->kc_social_toggle;
                    $image_attributes = wp_get_attachment_image_src($member_image, 'full');
                    //
                    $icon_1 = $item->kc_icon_picker1;
                    $icon_2 = $item->kc_icon_picker2;
                    $icon_3 = $item->kc_icon_picker3;
                    $icon_4 = $item->kc_icon_picker4;
                    //
                    $link_1 = explode('|', $item->kc_network_link1);
                    $link_2 = explode('|', $item->kc_network_link2);
                    $link_3 = explode('|', $item->kc_network_link3);
                    $link_4 = explode('|', $item->kc_network_link4);


                    if (empty($link_1[0])) {
                        $link_1[0] = '#';
                    }
                    if (empty($link_2[0])) {
                        $link_2[0] = '#';
                    }
                    if (empty($link_3[0])) {
                        $link_3[0] = '#';
                    }
                    if (empty($link_4[0])) {
                        $link_4[0] = '#';
                    }
                    if (empty($link_1[2])) {
                        $link_1[2] = '_self';
                    }
                    if (empty($link_2[2])) {
                        $link_2[2] = '_self';
                    }
                    if (empty($link_3[2])) {
                        $link_3[2] = '_self';
                    }
                    if (empty($link_4[2])) {
                        $link_4[2] = '_self';
                    }
                    ?>
                    <div class="swiper-slide">
                        <div class="member-wrapper">
                            <div class="img-wrapper">
                                <img src="<?php echo $image_attributes[0]; ?>" class="img-fluid"
                                     alt="<?php __('Member', 'kc_kc_addons'); ?>">
                            </div>
                            <div class="member-description">
                                <div class="content-wrapper">
                                    <div class="content d-flex flex-column justify-content-between">
                                        <div>
                                            <h5 class="name"><?php echo esc_attr($member_name); ?></h5>
                                            <p class="position"><?php echo esc_attr($member_position); ?></p>
                                        </div>
                                        <?php if ($member_social_toggle == 'yes'): ?>
                                            <div class="social-wrapper d-flex">
                                                <?php if ($icon_1): ?>
                                                    <a class="social-box" target="<?php echo esc_attr($link_1[2]); ?>"
                                                       href="<?php echo esc_url($link_1[0]); ?>">
                                                        <i class="<?php echo $icon_1; ?>"></i>
                                                    </a>
                                                <?php endif; ?>
                                                <?php if ($icon_2): ?>
                                                    <a class="social-box" target="<?php echo esc_attr($link_2[2]); ?>"
                                                       href="<?php echo esc_url($link_2[0]); ?>"><i
                                                                class="<?php echo $icon_2; ?>"></i></a>
                                                <?php endif; ?>
                                                <?php if ($icon_3): ?>
                                                    <a class="social-box" target="<?php echo esc_attr($link_3[2]); ?>"
                                                       href="<?php echo esc_url($link_3[0]); ?>"><i
                                                                class="<?php echo $icon_3; ?>"></i></a>
                                                <?php endif; ?>
                                                <?php if ($icon_4): ?>
                                                    <a class="social-box" target="<?php echo esc_attr($link_4[2]); ?>"
                                                       href="<?php echo esc_url($link_4[0]); ?>"><i
                                                                class="<?php echo $icon_4; ?>"></i></a>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="swiper-scrollbar-team"></div>
    </section>
<?php elseif ($team_slider_type == 'team-slider-type-2'): ?>

<?php endif; ?>