<?php
$img_src = $atts['kc_slide_bg'];
$img = wp_get_attachment_image_src( $img_src, 'full' );
$overlay = $atts['kc_hero_slide_overlay'];
?>
<div class="swiper-slide bg-size-cover bg-position-center <?php if($overlay =='yes'): ?> slide-overlay <?php endif; ?>?>" style="background-image:url('<?php echo $img[0]; ?>')">
    <div class="slide-inner d-flex flex-column justify-content-center align-items-center">
            <?php echo do_shortcode( str_replace( 'kc_hero_slider_slide#', 'kc_hero_slider_slide', $content));?>
    </div>
</div>